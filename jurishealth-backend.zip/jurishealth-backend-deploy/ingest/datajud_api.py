"""
Integrador com API Pública DataJud CNJ
Acessa dados reais de processos judiciais de forma legal e pública
"""

import requests
import time
from typing import List, Dict, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class DataJudAPI:
    """
    Cliente para API Pública do DataJud CNJ
    
    Documentação: https://datajud-wiki.cnj.jus.br/api-publica/
    """
    
    def __init__(self):
        self.base_url = "https://api-publica.datajud.cnj.jus.br"
        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'User-Agent': 'JurisHealth/1.0 (Plataforma de Oportunidades Judiciais de Saúde)'
        })
    
    def buscar_processo(self, numero_processo: str) -> Optional[Dict]:
        """
        Busca dados de um processo específico
        
        Args:
            numero_processo: Número CNJ do processo (formato: 0000000-00.0000.0.00.0000)
        
        Returns:
            Dicionário com dados do processo ou None se não encontrado
        """
        try:
            # Remove formatação do número
            numero_limpo = numero_processo.replace('-', '').replace('.', '')
            
            url = f"{self.base_url}/api_publica_processo/{numero_limpo}"
            
            logger.info(f"Consultando processo {numero_processo} na API DataJud")
            
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Processo {numero_processo} encontrado")
                return self._processar_dados(data)
            
            elif response.status_code == 404:
                logger.warning(f"⚠️ Processo {numero_processo} não encontrado")
                return None
            
            else:
                logger.error(f"❌ Erro {response.status_code} ao buscar processo")
                return None
                
        except Exception as e:
            logger.error(f"❌ Erro ao consultar API DataJud: {str(e)}")
            return None
    
    def buscar_processos_por_tribunal(
        self, 
        tribunal: str,
        data_inicio: str,
        data_fim: str,
        limite: int = 100
    ) -> List[Dict]:
        """
        Busca processos de um tribunal em um período
        
        Args:
            tribunal: Código do tribunal (ex: "TJMG", "TJSP")
            data_inicio: Data inicial (formato: YYYY-MM-DD)
            data_fim: Data final (formato: YYYY-MM-DD)
            limite: Número máximo de processos
        
        Returns:
            Lista de processos encontrados
        """
        try:
            url = f"{self.base_url}/api_publica_tribunal/{tribunal}"
            
            params = {
                'dataInicio': data_inicio,
                'dataFim': data_fim,
                'pagina': 1,
                'tamanhoPagina': min(limite, 100)
            }
            
            logger.info(f"Buscando processos do {tribunal} entre {data_inicio} e {data_fim}")
            
            response = self.session.get(url, params=params, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                processos = data.get('processos', [])
                logger.info(f"✅ Encontrados {len(processos)} processos")
                
                return [self._processar_dados(p) for p in processos]
            
            else:
                logger.error(f"❌ Erro {response.status_code} ao buscar processos")
                return []
                
        except Exception as e:
            logger.error(f"❌ Erro ao consultar API DataJud: {str(e)}")
            return []
    
    def buscar_processos_saude(
        self,
        tribunal: str = "TJMG",
        dias_atras: int = 30,
        limite: int = 50
    ) -> List[Dict]:
        """
        Busca processos de saúde de um tribunal
        
        Filtra por assuntos relacionados a saúde pública
        
        Args:
            tribunal: Código do tribunal
            dias_atras: Quantos dias atrás buscar
            limite: Número máximo de processos
        
        Returns:
            Lista de processos de saúde
        """
        from datetime import timedelta
        
        data_fim = datetime.now()
        data_inicio = data_fim - timedelta(days=dias_atras)
        
        processos = self.buscar_processos_por_tribunal(
            tribunal=tribunal,
            data_inicio=data_inicio.strftime('%Y-%m-%d'),
            data_fim=data_fim.strftime('%Y-%m-%d'),
            limite=limite
        )
        
        # Filtrar apenas processos de saúde
        processos_saude = []
        
        palavras_chave_saude = [
            'medicamento', 'tratamento', 'cirurgia', 'sus', 'saúde',
            'hospital', 'internação', 'quimioterapia', 'radioterapia',
            'hemodiálise', 'uti', 'procedimento médico'
        ]
        
        for processo in processos:
            assunto = processo.get('assunto', '').lower()
            
            if any(palavra in assunto for palavra in palavras_chave_saude):
                processos_saude.append(processo)
        
        logger.info(f"✅ Filtrados {len(processos_saude)} processos de saúde")
        
        return processos_saude[:limite]
    
    def _processar_dados(self, data: Dict) -> Dict:
        """
        Processa e estrutura dados do processo
        
        Args:
            data: Dados brutos da API
        
        Returns:
            Dados estruturados
        """
        try:
            # Extrair movimentações
            movimentacoes = data.get('movimentos', [])
            
            # Identificar sentença
            sentenca = None
            for mov in movimentacoes:
                nome_mov = mov.get('nome', '').lower()
                if 'sentença' in nome_mov or 'julgado procedente' in nome_mov:
                    sentenca = {
                        'data': mov.get('dataHora'),
                        'descricao': mov.get('complemento', ''),
                        'tipo': mov.get('nome')
                    }
                    break
            
            # Estruturar dados
            processo = {
                'numero_processo': data.get('numeroProcesso'),
                'tribunal': data.get('tribunal'),
                'classe': data.get('classe', {}).get('nome'),
                'assunto': data.get('assuntos', [{}])[0].get('nome') if data.get('assuntos') else None,
                'data_ajuizamento': data.get('dataAjuizamento'),
                'valor_causa': data.get('valorCausa'),
                'orgao_julgador': data.get('orgaoJulgador', {}).get('nome'),
                'comarca': data.get('orgaoJulgador', {}).get('comarca'),
                
                # Partes
                'autor': self._extrair_parte(data, 'AUTOR'),
                'reu': self._extrair_parte(data, 'RÉU'),
                
                # Sentença
                'sentenca': sentenca,
                'tem_sentenca': sentenca is not None,
                
                # Movimentações
                'movimentacoes': movimentacoes,
                'ultima_movimentacao': movimentacoes[0] if movimentacoes else None,
                
                # Metadados
                'fonte': 'DataJud CNJ',
                'data_consulta': datetime.now().isoformat()
            }
            
            return processo
            
        except Exception as e:
            logger.error(f"Erro ao processar dados: {str(e)}")
            return data
    
    def _extrair_parte(self, data: Dict, tipo: str) -> Optional[str]:
        """
        Extrai nome de uma parte do processo
        
        Args:
            data: Dados do processo
            tipo: Tipo da parte (AUTOR, RÉU, etc.)
        
        Returns:
            Nome da parte ou None
        """
        try:
            partes = data.get('partes', [])
            
            for parte in partes:
                if parte.get('polo') == tipo or parte.get('tipo') == tipo:
                    return parte.get('nome')
            
            return None
            
        except:
            return None


def testar_api():
    """Função de teste da API"""
    
    print("🧪 Testando API DataJud CNJ")
    print("=" * 60)
    
    api = DataJudAPI()
    
    # Teste 1: Buscar processo específico
    print("\n📋 Teste 1: Buscar processo específico")
    numero_teste = "0000000-00.2024.8.13.0024"  # Número de exemplo
    processo = api.buscar_processo(numero_teste)
    
    if processo:
        print(f"✅ Processo encontrado:")
        print(f"   Número: {processo.get('numero_processo')}")
        print(f"   Assunto: {processo.get('assunto')}")
        print(f"   Autor: {processo.get('autor')}")
        print(f"   Réu: {processo.get('reu')}")
        print(f"   Tem sentença: {processo.get('tem_sentenca')}")
    else:
        print("⚠️ Processo não encontrado (esperado para número de teste)")
    
    # Teste 2: Buscar processos de saúde
    print("\n📋 Teste 2: Buscar processos de saúde do TJMG")
    processos_saude = api.buscar_processos_saude(
        tribunal="TJMG",
        dias_atras=30,
        limite=5
    )
    
    print(f"✅ Encontrados {len(processos_saude)} processos de saúde")
    
    for i, p in enumerate(processos_saude, 1):
        print(f"\n{i}. {p.get('numero_processo')}")
        print(f"   Assunto: {p.get('assunto')}")
        print(f"   Réu: {p.get('reu')}")
        print(f"   Sentença: {'Sim' if p.get('tem_sentenca') else 'Não'}")
    
    print("\n" + "=" * 60)
    print("✅ Testes concluídos!")


if __name__ == "__main__":
    # Configurar logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    testar_api()

