"""
Scraper Real para TJMG - Tribunal de Justiça de Minas Gerais
Extrai processos de saúde do sistema PJe e consulta pública do TJMG
"""

import requests
from bs4 import BeautifulSoup
import re
import time
from typing import List, Dict, Optional
from datetime import datetime
import hashlib
from urllib.parse import urljoin, quote

class TJMGScraper:
    """
    Scraper para extrair processos de saúde do TJMG
    """
    
    def __init__(self):
        self.base_url = "https://www4.tjmg.jus.br"
        self.pje_url = "https://pje.tjmg.jus.br"
        self.consulta_url = f"{self.base_url}/juridico/sf/proc_resultado.jsp"
        
        # Headers para simular navegador real
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
    def buscar_processos_saude(self, comarca: str = "BELO HORIZONTE", 
                                limite: int = 50) -> List[Dict]:
        """
        Busca processos de saúde em uma comarca específica
        
        Args:
            comarca: Nome da comarca (ex: "BELO HORIZONTE")
            limite: Número máximo de processos a retornar
            
        Returns:
            Lista de dicionários com dados dos processos
        """
        processos = []
        
        # Palavras-chave para identificar processos de saúde
        keywords = [
            "medicamento",
            "tratamento médico",
            "cirurgia",
            "SUS",
            "saúde pública",
            "internação",
            "UTI",
            "quimioterapia",
            "radioterapia",
            "hemodiálise"
        ]
        
        for keyword in keywords:
            if len(processos) >= limite:
                break
                
            print(f"🔍 Buscando processos com palavra-chave: {keyword}")
            
            try:
                resultados = self._buscar_por_palavra_chave(keyword, comarca)
                processos.extend(resultados)
                
                # Delay para não sobrecarregar o servidor
                time.sleep(2)
                
            except Exception as e:
                print(f"❌ Erro ao buscar '{keyword}': {str(e)}")
                continue
        
        # Remover duplicatas
        processos_unicos = self._remover_duplicatas(processos)
        
        return processos_unicos[:limite]
    
    def _buscar_por_palavra_chave(self, keyword: str, comarca: str) -> List[Dict]:
        """
        Busca processos por palavra-chave específica
        """
        processos = []
        
        # Parâmetros de busca
        params = {
            'palavra_chave': keyword,
            'comarca': comarca,
            'natureza': 'CÍVEL',  # Processos cíveis (saúde geralmente é cível)
            'dt_inicial': '',  # Sem filtro de data inicial
            'dt_final': ''
        }
        
        try:
            # Fazer requisição
            response = self.session.get(
                self.consulta_url,
                params=params,
                timeout=30
            )
            
            if response.status_code != 200:
                print(f"⚠️ Status {response.status_code} para '{keyword}'")
                return []
            
            # Parse HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extrair processos da tabela de resultados
            tabela = soup.find('table', {'class': 'resultado'})
            
            if not tabela:
                print(f"ℹ️ Nenhum resultado para '{keyword}'")
                return []
            
            linhas = tabela.find_all('tr')[1:]  # Pular cabeçalho
            
            for linha in linhas:
                try:
                    processo = self._extrair_dados_linha(linha, keyword)
                    if processo and self._eh_processo_saude(processo):
                        processos.append(processo)
                except Exception as e:
                    print(f"⚠️ Erro ao processar linha: {str(e)}")
                    continue
            
            print(f"✅ Encontrados {len(processos)} processos para '{keyword}'")
            
        except requests.exceptions.RequestException as e:
            print(f"❌ Erro de conexão: {str(e)}")
        
        return processos
    
    def _extrair_dados_linha(self, linha, keyword: str) -> Optional[Dict]:
        """
        Extrai dados de uma linha da tabela de resultados
        """
        colunas = linha.find_all('td')
        
        if len(colunas) < 4:
            return None
        
        # Extrair número do processo
        numero_processo = colunas[0].get_text(strip=True)
        
        # Validar formato do número do processo
        if not re.match(r'\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}', numero_processo):
            return None
        
        # Extrair outras informações
        partes = colunas[1].get_text(strip=True)
        assunto = colunas[2].get_text(strip=True)
        situacao = colunas[3].get_text(strip=True) if len(colunas) > 3 else ""
        
        # Identificar autor (paciente) e réu (ente público)
        autor, reu = self._extrair_partes(partes)
        
        return {
            'numero_processo': numero_processo,
            'autor': autor,
            'reu': reu,
            'assunto': assunto,
            'situacao': situacao,
            'keyword_encontrada': keyword,
            'tribunal': 'TJMG',
            'data_captura': datetime.now().isoformat()
        }
    
    def _extrair_partes(self, texto_partes: str) -> tuple:
        """
        Extrai autor e réu do texto de partes
        """
        # Padrão comum: "AUTOR X RÉU" ou "AUTOR x RÉU"
        match = re.search(r'(.+?)\s+[xX]\s+(.+)', texto_partes)
        
        if match:
            autor = match.group(1).strip()
            reu = match.group(2).strip()
        else:
            # Se não encontrar padrão, dividir por vírgula
            partes = texto_partes.split(',')
            autor = partes[0].strip() if len(partes) > 0 else ""
            reu = partes[1].strip() if len(partes) > 1 else ""
        
        return autor, reu
    
    def _eh_processo_saude(self, processo: Dict) -> bool:
        """
        Verifica se o processo é realmente de saúde
        """
        # Verificar se o réu é ente público
        entes_publicos = [
            'ESTADO DE MINAS GERAIS',
            'MUNICÍPIO',
            'PREFEITURA',
            'UNIÃO',
            'SUS',
            'SECRETARIA DE SAÚDE',
            'FUNDO MUNICIPAL',
            'FUNDO ESTADUAL'
        ]
        
        reu_upper = processo.get('reu', '').upper()
        
        if not any(ente in reu_upper for ente in entes_publicos):
            return False
        
        # Verificar se o assunto é relacionado a saúde
        termos_saude = [
            'SAÚDE',
            'MEDICAMENTO',
            'TRATAMENTO',
            'CIRURGIA',
            'HOSPITAL',
            'MÉDICO',
            'SUS',
            'INTERNAÇÃO',
            'TERAPIA'
        ]
        
        assunto_upper = processo.get('assunto', '').upper()
        keyword_upper = processo.get('keyword_encontrada', '').upper()
        
        return any(termo in assunto_upper or termo in keyword_upper 
                  for termo in termos_saude)
    
    def obter_detalhes_processo(self, numero_processo: str) -> Optional[Dict]:
        """
        Obtém detalhes completos de um processo específico
        
        Args:
            numero_processo: Número do processo (formato: 0000000-00.0000.0.00.0000)
            
        Returns:
            Dicionário com detalhes do processo ou None
        """
        print(f"📄 Buscando detalhes do processo {numero_processo}")
        
        # URL de consulta de processo específico
        url = f"{self.base_url}/juridico/sf/proc_movimentacoes.jsp"
        
        params = {
            'listaProcessos': numero_processo
        }
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            
            if response.status_code != 200:
                return None
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extrair informações detalhadas
            detalhes = {
                'numero_processo': numero_processo,
                'movimentacoes': self._extrair_movimentacoes(soup),
                'valor_causa': self._extrair_valor_causa(soup),
                'comarca': self._extrair_comarca(soup),
                'vara': self._extrair_vara(soup),
                'data_distribuicao': self._extrair_data_distribuicao(soup),
                'situacao_atual': self._extrair_situacao_atual(soup)
            }
            
            return detalhes
            
        except Exception as e:
            print(f"❌ Erro ao obter detalhes: {str(e)}")
            return None
    
    def _extrair_movimentacoes(self, soup: BeautifulSoup) -> List[Dict]:
        """Extrai movimentações do processo"""
        movimentacoes = []
        
        tabela_mov = soup.find('table', {'id': 'movimentacoes'})
        
        if not tabela_mov:
            return []
        
        linhas = tabela_mov.find_all('tr')[1:]  # Pular cabeçalho
        
        for linha in linhas:
            colunas = linha.find_all('td')
            if len(colunas) >= 2:
                movimentacoes.append({
                    'data': colunas[0].get_text(strip=True),
                    'descricao': colunas[1].get_text(strip=True)
                })
        
        return movimentacoes
    
    def _extrair_valor_causa(self, soup: BeautifulSoup) -> Optional[float]:
        """Extrai valor da causa"""
        valor_elem = soup.find('span', {'id': 'valorCausa'})
        
        if not valor_elem:
            return None
        
        valor_texto = valor_elem.get_text(strip=True)
        
        # Remover "R$" e converter
        valor_texto = re.sub(r'[^\d,]', '', valor_texto)
        valor_texto = valor_texto.replace(',', '.')
        
        try:
            return float(valor_texto)
        except:
            return None
    
    def _extrair_comarca(self, soup: BeautifulSoup) -> str:
        """Extrai comarca"""
        comarca_elem = soup.find('span', {'id': 'comarca'})
        return comarca_elem.get_text(strip=True) if comarca_elem else ""
    
    def _extrair_vara(self, soup: BeautifulSoup) -> str:
        """Extrai vara"""
        vara_elem = soup.find('span', {'id': 'vara'})
        return vara_elem.get_text(strip=True) if vara_elem else ""
    
    def _extrair_data_distribuicao(self, soup: BeautifulSoup) -> Optional[str]:
        """Extrai data de distribuição"""
        data_elem = soup.find('span', {'id': 'dataDistribuicao'})
        
        if not data_elem:
            return None
        
        data_texto = data_elem.get_text(strip=True)
        
        # Converter para formato ISO
        try:
            data_obj = datetime.strptime(data_texto, '%d/%m/%Y')
            return data_obj.isoformat()
        except:
            return data_texto
    
    def _extrair_situacao_atual(self, soup: BeautifulSoup) -> str:
        """Extrai situação atual do processo"""
        situacao_elem = soup.find('span', {'id': 'situacao'})
        return situacao_elem.get_text(strip=True) if situacao_elem else ""
    
    def _remover_duplicatas(self, processos: List[Dict]) -> List[Dict]:
        """
        Remove processos duplicados baseado no número do processo
        """
        vistos = set()
        unicos = []
        
        for processo in processos:
            numero = processo.get('numero_processo')
            if numero and numero not in vistos:
                vistos.add(numero)
                unicos.append(processo)
        
        return unicos
    
    def _hash_paciente(self, nome: str) -> str:
        """
        Gera hash anônimo do nome do paciente (LGPD)
        """
        return hashlib.sha256(nome.encode()).hexdigest()[:16]


# Função auxiliar para uso direto
def buscar_processos_tjmg(comarca: str = "BELO HORIZONTE", 
                          limite: int = 50) -> List[Dict]:
    """
    Função auxiliar para buscar processos do TJMG
    
    Args:
        comarca: Nome da comarca
        limite: Número máximo de processos
        
    Returns:
        Lista de processos encontrados
    """
    scraper = TJMGScraper()
    return scraper.buscar_processos_saude(comarca, limite)


if __name__ == "__main__":
    # Teste do scraper
    print("🚀 Iniciando scraper TJMG...")
    print("=" * 60)
    
    scraper = TJMGScraper()
    
    # Buscar processos
    processos = scraper.buscar_processos_saude(
        comarca="BELO HORIZONTE",
        limite=10
    )
    
    print("\n" + "=" * 60)
    print(f"✅ Total de processos encontrados: {len(processos)}")
    print("=" * 60)
    
    # Mostrar primeiros 3 processos
    for i, processo in enumerate(processos[:3], 1):
        print(f"\n📋 Processo {i}:")
        print(f"   Número: {processo.get('numero_processo')}")
        print(f"   Assunto: {processo.get('assunto')}")
        print(f"   Réu: {processo.get('reu')}")
        print(f"   Situação: {processo.get('situacao')}")
    
    # Obter detalhes do primeiro processo
    if processos:
        print("\n" + "=" * 60)
        print("🔍 Obtendo detalhes do primeiro processo...")
        detalhes = scraper.obter_detalhes_processo(processos[0]['numero_processo'])
        
        if detalhes:
            print(f"   Comarca: {detalhes.get('comarca')}")
            print(f"   Vara: {detalhes.get('vara')}")
            print(f"   Valor da Causa: R$ {detalhes.get('valor_causa', 0):,.2f}")
            print(f"   Movimentações: {len(detalhes.get('movimentacoes', []))}")

