"""
Integração do Scraper TJMG com a API JurisHealth
Processa dados capturados e insere no banco de dados
"""

from typing import List, Dict, Optional
from datetime import datetime, timedelta
import re
from sqlalchemy.orm import Session

from .tjmg_scraper import TJMGScraper
from ..models import Case, Hospital
from ..crud import create_case
from ..schemas import CaseCreate
import hashlib


class TJMGIntegration:
    """
    Integra o scraper TJMG com o banco de dados da JurisHealth
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.scraper = TJMGScraper()
        
        # Mapeamento de palavras-chave para procedimentos
        self.procedimento_map = {
            'medicamento': 'Fornecimento de Medicamento',
            'quimioterapia': 'Quimioterapia',
            'radioterapia': 'Radioterapia',
            'cirurgia': 'Cirurgia',
            'hemodiálise': 'Hemodiálise',
            'internação': 'Internação Hospitalar',
            'uti': 'Internação em UTI',
            'tratamento': 'Tratamento Médico',
            'exame': 'Exame Médico',
            'transplante': 'Transplante'
        }
    
    def executar_captura(self, comarca: str = "BELO HORIZONTE", 
                        limite: int = 50) -> Dict:
        """
        Executa captura de processos e insere no banco
        
        Args:
            comarca: Comarca para buscar
            limite: Número máximo de processos
            
        Returns:
            Estatísticas da captura
        """
        print(f"🚀 Iniciando captura TJMG - Comarca: {comarca}")
        
        stats = {
            'total_encontrados': 0,
            'total_novos': 0,
            'total_duplicados': 0,
            'total_erros': 0,
            'inicio': datetime.now().isoformat()
        }
        
        try:
            # Buscar processos
            processos_raw = self.scraper.buscar_processos_saude(comarca, limite)
            stats['total_encontrados'] = len(processos_raw)
            
            print(f"✅ Encontrados {len(processos_raw)} processos")
            
            # Processar cada processo
            for processo_raw in processos_raw:
                try:
                    # Verificar se já existe
                    numero = processo_raw.get('numero_processo')
                    
                    if self._processo_existe(numero):
                        stats['total_duplicados'] += 1
                        print(f"⏭️ Processo {numero} já existe, pulando...")
                        continue
                    
                    # Obter detalhes completos
                    detalhes = self.scraper.obter_detalhes_processo(numero)
                    
                    # Processar e inserir
                    case_data = self._processar_processo(processo_raw, detalhes)
                    
                    if case_data:
                        case = create_case(self.db, case_data)
                        stats['total_novos'] += 1
                        print(f"✅ Processo {numero} inserido com ID {case.id}")
                    
                except Exception as e:
                    stats['total_erros'] += 1
                    print(f"❌ Erro ao processar {processo_raw.get('numero_processo')}: {str(e)}")
                    continue
            
            stats['fim'] = datetime.now().isoformat()
            
            print("\n" + "=" * 60)
            print("📊 ESTATÍSTICAS DA CAPTURA")
            print("=" * 60)
            print(f"Total encontrados: {stats['total_encontrados']}")
            print(f"Novos inseridos: {stats['total_novos']}")
            print(f"Duplicados: {stats['total_duplicados']}")
            print(f"Erros: {stats['total_erros']}")
            print("=" * 60)
            
            return stats
            
        except Exception as e:
            stats['erro_geral'] = str(e)
            stats['fim'] = datetime.now().isoformat()
            print(f"❌ Erro geral na captura: {str(e)}")
            return stats
    
    def _processo_existe(self, numero_processo: str) -> bool:
        """
        Verifica se processo já existe no banco
        """
        existing = self.db.query(Case).filter(
            Case.case_number == numero_processo
        ).first()
        
        return existing is not None
    
    def _processar_processo(self, processo_raw: Dict, 
                           detalhes: Optional[Dict]) -> Optional[CaseCreate]:
        """
        Processa dados brutos e cria objeto CaseCreate
        """
        try:
            # Extrair informações básicas
            numero = processo_raw.get('numero_processo')
            assunto = processo_raw.get('assunto', '')
            reu = processo_raw.get('reu', '')
            autor = processo_raw.get('autor', '')
            
            # Identificar procedimento
            procedimento = self._identificar_procedimento(assunto, processo_raw.get('keyword_encontrada', ''))
            
            # Identificar município
            municipio = self._identificar_municipio(reu, detalhes)
            
            # Estimar valor
            valor_estimado = self._estimar_valor(procedimento, detalhes)
            
            # Calcular prazo
            prazo = self._calcular_prazo(detalhes)
            
            # Hash do paciente (LGPD)
            paciente_hash = self._hash_paciente(autor)
            
            # Determinar status
            status = self._determinar_status(detalhes)
            
            # Criar objeto CaseCreate
            case_data = CaseCreate(
                court="TJMG",
                jurisdiction="Saúde",
                case_number=numero,
                patient_hash=paciente_hash,
                procedure=procedimento,
                municipality=municipio,
                value_estimate=valor_estimado,
                status=status,
                due_date=prazo,
                meta={
                    'assunto_original': assunto,
                    'reu': reu,
                    'comarca': detalhes.get('comarca') if detalhes else '',
                    'vara': detalhes.get('vara') if detalhes else '',
                    'data_distribuicao': detalhes.get('data_distribuicao') if detalhes else '',
                    'situacao_tjmg': detalhes.get('situacao_atual') if detalhes else '',
                    'fonte': 'scraper_tjmg_v1'
                }
            )
            
            return case_data
            
        except Exception as e:
            print(f"❌ Erro ao processar processo: {str(e)}")
            return None
    
    def _identificar_procedimento(self, assunto: str, keyword: str) -> str:
        """
        Identifica o tipo de procedimento baseado no assunto
        """
        texto = f"{assunto} {keyword}".lower()
        
        for palavra_chave, procedimento in self.procedimento_map.items():
            if palavra_chave in texto:
                return procedimento
        
        # Padrão se não identificar
        return "Procedimento de Saúde"
    
    def _identificar_municipio(self, reu: str, detalhes: Optional[Dict]) -> str:
        """
        Identifica o município responsável
        """
        # Tentar extrair do nome do réu
        match = re.search(r'MUNICÍPIO DE ([A-ZÁÉÍÓÚÂÊÔÃÕÇ\s]+)', reu.upper())
        
        if match:
            return match.group(1).strip().title()
        
        # Tentar da comarca
        if detalhes and detalhes.get('comarca'):
            return detalhes['comarca'].title()
        
        # Padrão
        return "Belo Horizonte"
    
    def _estimar_valor(self, procedimento: str, detalhes: Optional[Dict]) -> float:
        """
        Estima valor do procedimento
        """
        # Se tiver valor da causa, usar
        if detalhes and detalhes.get('valor_causa'):
            return float(detalhes['valor_causa'])
        
        # Tabela de valores médios por procedimento (baseado em CBHPM)
        valores_medios = {
            'Quimioterapia': 35000.0,
            'Radioterapia': 28000.0,
            'Cirurgia': 45000.0,
            'Hemodiálise': 22000.0,
            'Internação em UTI': 50000.0,
            'Internação Hospitalar': 30000.0,
            'Transplante': 150000.0,
            'Fornecimento de Medicamento': 25000.0,
            'Exame Médico': 5000.0,
            'Tratamento Médico': 20000.0,
            'Procedimento de Saúde': 30000.0
        }
        
        return valores_medios.get(procedimento, 30000.0)
    
    def _calcular_prazo(self, detalhes: Optional[Dict]) -> Optional[str]:
        """
        Calcula prazo judicial para execução
        """
        # Se tiver movimentações, verificar última
        if detalhes and detalhes.get('movimentacoes'):
            movimentacoes = detalhes['movimentacoes']
            
            # Verificar se há sentença/decisão
            for mov in movimentacoes:
                descricao = mov.get('descricao', '').lower()
                
                if any(termo in descricao for termo in ['sentença', 'decisão', 'deferido', 'procedente']):
                    # Prazo padrão: 90 dias após decisão favorável
                    try:
                        data_mov = datetime.strptime(mov['data'], '%d/%m/%Y')
                        prazo = data_mov + timedelta(days=90)
                        return prazo.date().isoformat()
                    except:
                        pass
        
        # Prazo padrão: 90 dias a partir de hoje
        prazo_padrao = datetime.now() + timedelta(days=90)
        return prazo_padrao.date().isoformat()
    
    def _hash_paciente(self, nome: str) -> str:
        """
        Gera hash anônimo do nome do paciente (LGPD)
        """
        return hashlib.sha256(nome.encode()).hexdigest()[:16]
    
    def _determinar_status(self, detalhes: Optional[Dict]) -> str:
        """
        Determina status do processo
        """
        if not detalhes:
            return "open"
        
        situacao = detalhes.get('situacao_atual', '').lower()
        
        # Mapear situação TJMG para status interno
        if any(termo in situacao for termo in ['arquivado', 'baixado', 'extinto']):
            return "closed"
        
        if any(termo in situacao for termo in ['sentença', 'julgado', 'transitado']):
            return "open"  # Pronto para orçamentos
        
        return "pending"  # Ainda em andamento


# Função auxiliar para uso na API
def executar_captura_tjmg(db: Session, comarca: str = "BELO HORIZONTE", 
                         limite: int = 50) -> Dict:
    """
    Função auxiliar para executar captura TJMG
    """
    integration = TJMGIntegration(db)
    return integration.executar_captura(comarca, limite)

