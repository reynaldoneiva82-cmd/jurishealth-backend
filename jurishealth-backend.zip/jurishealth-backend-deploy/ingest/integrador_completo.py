"""
Integrador Completo JurisHealth
Combina múltiplas fontes para obter dados completos de processos
"""

from .datajud_api import DataJudAPI
from .pje_consulta import PJeConsultaPublica
from typing import List, Dict, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class IntegradorJurisHealth:
    """
    Integrador completo que combina:
    1. API DataJud CNJ - Metadados e movimentações
    2. PJe Consulta Pública - Documentos e sentenças
    3. Análise inteligente - Extração de procedimentos médicos
    """
    
    def __init__(self, tribunal: str = "TJMG"):
        self.tribunal = tribunal
        self.datajud = DataJudAPI()
        self.pje = PJeConsultaPublica(tribunal=tribunal)
    
    def buscar_processo_completo(self, numero_processo: str) -> Optional[Dict]:
        """
        Busca dados completos de um processo combinando múltiplas fontes
        
        Args:
            numero_processo: Número CNJ do processo
        
        Returns:
            Dicionário com dados completos do processo
        """
        logger.info(f"🔍 Buscando dados completos do processo {numero_processo}")
        
        processo_completo = {
            'numero_processo': numero_processo,
            'tribunal': self.tribunal,
            'data_consulta': datetime.now().isoformat(),
            'fontes': []
        }
        
        # Fonte 1: API DataJud CNJ
        logger.info("📡 Consultando API DataJud CNJ...")
        dados_datajud = self.datajud.buscar_processo(numero_processo)
        
        if dados_datajud:
            processo_completo.update(dados_datajud)
            processo_completo['fontes'].append('DataJud CNJ')
            logger.info("✅ Dados obtidos do DataJud")
        else:
            logger.warning("⚠️ Processo não encontrado no DataJud")
        
        # Fonte 2: PJe Consulta Pública
        logger.info("📄 Consultando PJe Consulta Pública...")
        dados_pje = self.pje.buscar_processo(numero_processo)
        
        if dados_pje and 'erro' not in dados_pje:
            # Mesclar dados do PJe
            processo_completo['documentos'] = dados_pje.get('documentos', [])
            
            # Se PJe tem sentença e DataJud não, usar do PJe
            if not processo_completo.get('sentenca') and dados_pje.get('sentenca'):
                processo_completo['sentenca'] = dados_pje['sentenca']
                processo_completo['tem_sentenca'] = True
            
            processo_completo['fontes'].append('PJe Consulta Pública')
            logger.info("✅ Dados obtidos do PJe")
        else:
            logger.warning("⚠️ Processo não encontrado no PJe")
        
        # Análise inteligente
        logger.info("🤖 Aplicando análise inteligente...")
        processo_completo = self._analisar_processo(processo_completo)
        
        logger.info(f"✅ Processo completo obtido de {len(processo_completo['fontes'])} fonte(s)")
        
        return processo_completo
    
    def buscar_oportunidades_saude(
        self,
        dias_atras: int = 30,
        limite: int = 50,
        apenas_com_sentenca: bool = True
    ) -> List[Dict]:
        """
        Busca oportunidades de processos de saúde
        
        Args:
            dias_atras: Quantos dias atrás buscar
            limite: Número máximo de processos
            apenas_com_sentenca: Se True, retorna apenas processos com sentença procedente
        
        Returns:
            Lista de oportunidades
        """
        logger.info(f"🔍 Buscando oportunidades de saúde ({dias_atras} dias, limite {limite})")
        
        # Buscar processos de saúde no DataJud
        processos = self.datajud.buscar_processos_saude(
            tribunal=self.tribunal,
            dias_atras=dias_atras,
            limite=limite * 2  # Buscar mais para filtrar depois
        )
        
        oportunidades = []
        
        for processo in processos:
            # Enriquecer com dados do PJe se necessário
            if not processo.get('tem_sentenca'):
                numero = processo.get('numero_processo')
                dados_pje = self.pje.buscar_processo(numero)
                
                if dados_pje and dados_pje.get('tem_sentenca'):
                    processo['sentenca'] = dados_pje['sentenca']
                    processo['tem_sentenca'] = True
                    processo['documentos'] = dados_pje.get('documentos', [])
            
            # Filtrar apenas com sentença se solicitado
            if apenas_com_sentenca and not processo.get('tem_sentenca'):
                continue
            
            # Analisar processo
            processo_analisado = self._analisar_processo(processo)
            
            # Adicionar às oportunidades
            oportunidades.append(processo_analisado)
            
            if len(oportunidades) >= limite:
                break
        
        logger.info(f"✅ Encontradas {len(oportunidades)} oportunidades")
        
        return oportunidades
    
    def _analisar_processo(self, processo: Dict) -> Dict:
        """
        Aplica análise inteligente ao processo
        
        Identifica:
        - Tipo de procedimento médico
        - Valor estimado
        - Prazo para execução
        - Status da oportunidade
        """
        # Identificar procedimento
        assunto = processo.get('assunto', '').lower()
        
        procedimento = self._identificar_procedimento(assunto)
        processo['procedimento_identificado'] = procedimento
        
        # Estimar valor
        if not processo.get('valor_causa'):
            processo['valor_estimado'] = self._estimar_valor(procedimento)
        else:
            processo['valor_estimado'] = processo['valor_causa']
        
        # Calcular prazo
        if processo.get('tem_sentenca'):
            processo['prazo_execucao'] = self._calcular_prazo(processo['sentenca'])
        
        # Determinar status da oportunidade
        processo['status_oportunidade'] = self._determinar_status(processo)
        
        # Extrair informações médicas
        processo['info_medica'] = self._extrair_info_medica(processo)
        
        return processo
    
    def _identificar_procedimento(self, texto: str) -> str:
        """Identifica tipo de procedimento médico"""
        texto_lower = texto.lower()
        
        procedimentos = {
            'Fornecimento de Medicamento': ['medicamento', 'remédio', 'fármaco', 'droga'],
            'Cirurgia Oncológica': ['cirurgia', 'oncológica', 'câncer', 'tumor'],
            'Quimioterapia': ['quimioterapia', 'quimio'],
            'Radioterapia': ['radioterapia', 'radio'],
            'Hemodiálise': ['hemodiálise', 'diálise', 'hemo'],
            'Internação em UTI': ['uti', 'unidade de terapia intensiva'],
            'Internação Hospitalar': ['internação', 'internamento'],
            'Tratamento Médico': ['tratamento']
        }
        
        for procedimento, palavras in procedimentos.items():
            if any(palavra in texto_lower for palavra in palavras):
                return procedimento
        
        return 'Tratamento de Saúde'
    
    def _estimar_valor(self, procedimento: str) -> float:
        """Estima valor baseado em tabela CBHPM"""
        valores_base = {
            'Fornecimento de Medicamento': 15000,
            'Cirurgia Oncológica': 45000,
            'Quimioterapia': 35000,
            'Radioterapia': 28000,
            'Hemodiálise': 12000,
            'Internação em UTI': 50000,
            'Internação Hospitalar': 20000,
            'Tratamento Médico': 18000,
            'Tratamento de Saúde': 20000
        }
        
        return valores_base.get(procedimento, 20000)
    
    def _calcular_prazo(self, sentenca: Dict) -> str:
        """Calcula prazo para execução baseado na sentença"""
        # Normalmente 90 dias após trânsito em julgado
        return "90 dias após trânsito em julgado"
    
    def _determinar_status(self, processo: Dict) -> str:
        """Determina status da oportunidade"""
        if not processo.get('tem_sentenca'):
            return 'aguardando_sentenca'
        
        sentenca = processo.get('sentenca', {})
        resultado = sentenca.get('resultado', '').lower()
        
        if 'procedente' in resultado:
            return 'disponivel'
        elif 'improcedente' in resultado:
            return 'indisponivel'
        else:
            return 'em_analise'
    
    def _extrair_info_medica(self, processo: Dict) -> Dict:
        """Extrai informações médicas relevantes"""
        info = {
            'procedimento': processo.get('procedimento_identificado'),
            'valor_estimado': processo.get('valor_estimado'),
            'prazo': processo.get('prazo_execucao'),
            'documentos_disponiveis': []
        }
        
        # Listar documentos relevantes
        for doc in processo.get('documentos', []):
            tipo = doc.get('tipo')
            if tipo in ['sentenca', 'laudo', 'receita_medica', 'peticao_inicial']:
                info['documentos_disponiveis'].append({
                    'tipo': tipo,
                    'nome': doc.get('nome'),
                    'url': doc.get('url')
                })
        
        return info


def exemplo_uso():
    """Exemplo de uso do integrador"""
    
    print("🏥 JurisHealth - Integrador Completo")
    print("=" * 60)
    
    integrador = IntegradorJurisHealth(tribunal="TJMG")
    
    # Exemplo 1: Buscar processo específico
    print("\n📋 Exemplo 1: Buscar processo completo")
    numero = "5000000-00.2024.8.13.0024"
    
    processo = integrador.buscar_processo_completo(numero)
    
    print(f"\n✅ Processo: {processo.get('numero_processo')}")
    print(f"   Fontes: {', '.join(processo.get('fontes', []))}")
    print(f"   Procedimento: {processo.get('procedimento_identificado')}")
    print(f"   Valor estimado: R$ {processo.get('valor_estimado'):,.2f}")
    print(f"   Status: {processo.get('status_oportunidade')}")
    print(f"   Documentos: {len(processo.get('documentos', []))}")
    
    # Exemplo 2: Buscar oportunidades
    print("\n\n📋 Exemplo 2: Buscar oportunidades de saúde")
    
    oportunidades = integrador.buscar_oportunidades_saude(
        dias_atras=30,
        limite=5,
        apenas_com_sentenca=True
    )
    
    print(f"\n✅ Encontradas {len(oportunidades)} oportunidades:")
    
    for i, op in enumerate(oportunidades, 1):
        print(f"\n{i}. {op.get('numero_processo')}")
        print(f"   Procedimento: {op.get('procedimento_identificado')}")
        print(f"   Valor: R$ {op.get('valor_estimado'):,.2f}")
        print(f"   Status: {op.get('status_oportunidade')}")
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    exemplo_uso()

