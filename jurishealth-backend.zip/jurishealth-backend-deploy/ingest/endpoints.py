"""
Endpoints da API para captura de processos TJMG
"""

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import Dict
from pydantic import BaseModel

from ..db import get_db
from .tjmg_integration import executar_captura_tjmg

router = APIRouter(prefix="/ingest", tags=["Ingestão de Processos"])


class CapturaRequest(BaseModel):
    """Request para captura de processos"""
    comarca: str = "BELO HORIZONTE"
    limite: int = 50


class CapturaResponse(BaseModel):
    """Response da captura"""
    message: str
    stats: Dict


@router.post("/tjmg/capturar", response_model=CapturaResponse)
def capturar_processos_tjmg(
    request: CapturaRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Captura processos de saúde do TJMG
    
    **Parâmetros:**
    - comarca: Nome da comarca (ex: "BELO HORIZONTE")
    - limite: Número máximo de processos a capturar (padrão: 50)
    
    **Retorna:**
    - Estatísticas da captura
    
    **Exemplo:**
    ```json
    {
        "comarca": "BELO HORIZONTE",
        "limite": 20
    }
    ```
    
    **Nota:** A captura pode demorar alguns minutos dependendo do número de processos.
    """
    try:
        # Executar captura
        stats = executar_captura_tjmg(
            db=db,
            comarca=request.comarca,
            limite=request.limite
        )
        
        return CapturaResponse(
            message=f"Captura concluída para comarca {request.comarca}",
            stats=stats
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao executar captura: {str(e)}"
        )


@router.post("/tjmg/capturar-async", response_model=Dict)
def capturar_processos_tjmg_async(
    request: CapturaRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Captura processos de saúde do TJMG em background
    
    Executa a captura de forma assíncrona, retornando imediatamente.
    Útil para capturas de grande volume.
    
    **Parâmetros:**
    - comarca: Nome da comarca
    - limite: Número máximo de processos
    
    **Retorna:**
    - Confirmação de que a captura foi iniciada
    """
    # Adicionar tarefa em background
    background_tasks.add_task(
        executar_captura_tjmg,
        db=db,
        comarca=request.comarca,
        limite=request.limite
    )
    
    return {
        "message": "Captura iniciada em background",
        "comarca": request.comarca,
        "limite": request.limite,
        "status": "processing"
    }


@router.get("/tjmg/status")
def verificar_status_tjmg():
    """
    Verifica status da integração com TJMG
    
    **Retorna:**
    - Status da conexão com TJMG
    - Última captura realizada
    """
    try:
        from .tjmg_scraper import TJMGScraper
        
        scraper = TJMGScraper()
        
        # Tentar fazer uma requisição simples
        response = scraper.session.get(
            scraper.base_url,
            timeout=10
        )
        
        online = response.status_code == 200
        
        return {
            "tribunal": "TJMG",
            "status": "online" if online else "offline",
            "url": scraper.base_url,
            "ultima_verificacao": "agora"
        }
        
    except Exception as e:
        return {
            "tribunal": "TJMG",
            "status": "erro",
            "erro": str(e)
        }


@router.get("/comarcas-disponiveis")
def listar_comarcas_disponiveis():
    """
    Lista comarcas disponíveis para captura no TJMG
    
    **Retorna:**
    - Lista de comarcas principais de Minas Gerais
    """
    comarcas = [
        "BELO HORIZONTE",
        "CONTAGEM",
        "UBERLÂNDIA",
        "JUIZ DE FORA",
        "BETIM",
        "MONTES CLAROS",
        "RIBEIRÃO DAS NEVES",
        "UBERABA",
        "GOVERNADOR VALADARES",
        "IPATINGA",
        "SETE LAGOAS",
        "DIVINÓPOLIS",
        "SANTA LUZIA",
        "IBIRITÉ",
        "POÇOS DE CALDAS",
        "PATOS DE MINAS",
        "TEÓFILO OTONI",
        "SABARÁ",
        "POUSO ALEGRE",
        "BARBACENA"
    ]
    
    return {
        "total": len(comarcas),
        "comarcas": comarcas,
        "estado": "Minas Gerais",
        "tribunal": "TJMG"
    }

