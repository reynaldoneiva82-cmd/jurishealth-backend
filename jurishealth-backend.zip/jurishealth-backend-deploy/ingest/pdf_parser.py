# Placeholder: Funções para extrair texto/entidades de PDFs de decisões/acórdãos.
# Em produção, considere pdfminer.six, pytesseract (OCR), e regras específicas para identificar
# procedimento, município, prazos, valores e partes.
def extract_entities_from_text(text: str) -> dict:
    # Exemplo simplificado: procure por 'Município de X' e 'R$ 12.345,67'
    import re
    m_city = re.search(r"Munic[ií]pio de ([A-Za-z\s]+)", text)
    m_value = re.search(r"R\$\s?([0-9\.]+,[0-9]{{2}})", text)
    return {
        "municipality": m_city.group(1).strip() if m_city else None,
        "value_estimate_raw": m_value.group(1) if m_value else None
    }
