"""
Integrador com Consulta Pública do PJe
Acessa documentos de processos (sentenças, petições, laudos)
"""

import requests
from bs4 import BeautifulSoup
import re
from typing import List, Dict, Optional
import logging
import time

logger = logging.getLogger(__name__)


class PJeConsultaPublica:
    """
    Cliente para Consulta Pública do PJe (Processo Judicial Eletrônico)
    
    Acessa documentos públicos sem necessidade de login
    """
    
    def __init__(self, tribunal: str = "TJMG"):
        self.tribunal = tribunal
        self.base_url = self._get_url_tribunal(tribunal)
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
        })
    
    def _get_url_tribunal(self, tribunal: str) -> str:
        """Retorna URL base do PJe para cada tribunal"""
        urls = {
            'TJMG': 'https://pje.tjmg.jus.br/pje',
            'TJSP': 'https://esaj.tjsp.jus.br/cpopg',
            'TJRJ': 'https://www3.tjrj.jus.br/consultaprocessual',
            'TJDF': 'https://pje.tjdft.jus.br/pje',
            'TRF1': 'https://pje1g.trf1.jus.br/consultapublica'
        }
        
        return urls.get(tribunal, urls['TJMG'])
    
    def buscar_processo(self, numero_processo: str) -> Optional[Dict]:
        """
        Busca dados públicos de um processo
        
        Args:
            numero_processo: Número CNJ do processo
        
        Returns:
            Dicionário com dados do processo e documentos
        """
        try:
            logger.info(f"Consultando processo {numero_processo} no PJe {self.tribunal}")
            
            # URL de consulta pública
            url_consulta = f"{self.base_url}/ConsultaPublica/DetalheProcessoConsultaPublica/listView.seam"
            
            # Parâmetros da consulta
            params = {
                'ca': 'num',
                'numero': numero_processo.replace('-', '').replace('.', '')
            }
            
            response = self.session.get(url_consulta, params=params, timeout=30)
            
            if response.status_code == 200:
                return self._extrair_dados_processo(response.text, numero_processo)
            else:
                logger.error(f"❌ Erro {response.status_code} ao consultar PJe")
                return None
                
        except Exception as e:
            logger.error(f"❌ Erro ao consultar PJe: {str(e)}")
            return None
    
    def _extrair_dados_processo(self, html: str, numero_processo: str) -> Dict:
        """
        Extrai dados do HTML da consulta pública
        
        Args:
            html: HTML da página
            numero_processo: Número do processo
        
        Returns:
            Dados estruturados do processo
        """
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            dados = {
                'numero_processo': numero_processo,
                'tribunal': self.tribunal,
                'movimentacoes': [],
                'documentos': [],
                'partes': {},
                'fonte': f'PJe {self.tribunal}'
            }
            
            # Extrair dados básicos
            dados['classe'] = self._extrair_campo(soup, 'Classe')
            dados['assunto'] = self._extrair_campo(soup, 'Assunto')
            dados['area'] = self._extrair_campo(soup, 'Área')
            dados['orgao_julgador'] = self._extrair_campo(soup, 'Órgão julgador')
            dados['valor_causa'] = self._extrair_campo(soup, 'Valor da causa')
            
            # Extrair partes
            dados['partes'] = self._extrair_partes(soup)
            
            # Extrair movimentações
            dados['movimentacoes'] = self._extrair_movimentacoes(soup)
            
            # Extrair documentos
            dados['documentos'] = self._extrair_documentos(soup)
            
            # Identificar sentença
            dados['sentenca'] = self._identificar_sentenca(dados['movimentacoes'], dados['documentos'])
            dados['tem_sentenca'] = dados['sentenca'] is not None
            
            logger.info(f"✅ Dados extraídos: {len(dados['movimentacoes'])} movimentações, {len(dados['documentos'])} documentos")
            
            return dados
            
        except Exception as e:
            logger.error(f"Erro ao extrair dados: {str(e)}")
            return {'numero_processo': numero_processo, 'erro': str(e)}
    
    def _extrair_campo(self, soup: BeautifulSoup, label: str) -> Optional[str]:
        """Extrai valor de um campo específico"""
        try:
            elemento = soup.find('label', string=re.compile(label, re.I))
            if elemento:
                valor = elemento.find_next_sibling()
                return valor.get_text(strip=True) if valor else None
            return None
        except:
            return None
    
    def _extrair_partes(self, soup: BeautifulSoup) -> Dict:
        """Extrai informações das partes do processo"""
        partes = {}
        
        try:
            # Procurar seção de partes
            secao_partes = soup.find('div', {'id': re.compile('partes', re.I)})
            
            if secao_partes:
                # Extrair autor
                autor_elem = secao_partes.find(string=re.compile('Autor|Requerente', re.I))
                if autor_elem:
                    partes['autor'] = autor_elem.find_next().get_text(strip=True)
                
                # Extrair réu
                reu_elem = secao_partes.find(string=re.compile('Réu|Requerido', re.I))
                if reu_elem:
                    partes['reu'] = reu_elem.find_next().get_text(strip=True)
        
        except Exception as e:
            logger.warning(f"Erro ao extrair partes: {str(e)}")
        
        return partes
    
    def _extrair_movimentacoes(self, soup: BeautifulSoup) -> List[Dict]:
        """Extrai movimentações do processo"""
        movimentacoes = []
        
        try:
            # Procurar tabela de movimentações
            tabela = soup.find('table', {'id': re.compile('movimentacoes|timeline', re.I)})
            
            if tabela:
                linhas = tabela.find_all('tr')
                
                for linha in linhas:
                    colunas = linha.find_all('td')
                    
                    if len(colunas) >= 2:
                        mov = {
                            'data': colunas[0].get_text(strip=True),
                            'descricao': colunas[1].get_text(strip=True)
                        }
                        movimentacoes.append(mov)
        
        except Exception as e:
            logger.warning(f"Erro ao extrair movimentações: {str(e)}")
        
        return movimentacoes
    
    def _extrair_documentos(self, soup: BeautifulSoup) -> List[Dict]:
        """Extrai lista de documentos disponíveis"""
        documentos = []
        
        try:
            # Procurar links de documentos
            links = soup.find_all('a', href=re.compile('documento|pdf', re.I))
            
            for link in links:
                doc = {
                    'nome': link.get_text(strip=True),
                    'url': link.get('href'),
                    'tipo': self._identificar_tipo_documento(link.get_text(strip=True))
                }
                documentos.append(doc)
        
        except Exception as e:
            logger.warning(f"Erro ao extrair documentos: {str(e)}")
        
        return documentos
    
    def _identificar_tipo_documento(self, nome: str) -> str:
        """Identifica tipo do documento pelo nome"""
        nome_lower = nome.lower()
        
        if 'sentença' in nome_lower or 'decisão' in nome_lower:
            return 'sentenca'
        elif 'petição inicial' in nome_lower or 'inicial' in nome_lower:
            return 'peticao_inicial'
        elif 'laudo' in nome_lower or 'perícia' in nome_lower:
            return 'laudo'
        elif 'receita' in nome_lower or 'prescrição' in nome_lower:
            return 'receita_medica'
        else:
            return 'outro'
    
    def _identificar_sentenca(self, movimentacoes: List[Dict], documentos: List[Dict]) -> Optional[Dict]:
        """Identifica sentença nas movimentações ou documentos"""
        
        # Procurar em movimentações
        for mov in movimentacoes:
            descricao = mov.get('descricao', '').lower()
            
            if any(termo in descricao for termo in ['sentença', 'julgado procedente', 'julgo procedente']):
                return {
                    'data': mov.get('data'),
                    'descricao': mov.get('descricao'),
                    'tipo': 'movimentacao',
                    'resultado': 'procedente' if 'procedente' in descricao else 'desconhecido'
                }
        
        # Procurar em documentos
        for doc in documentos:
            if doc.get('tipo') == 'sentenca':
                return {
                    'nome': doc.get('nome'),
                    'url': doc.get('url'),
                    'tipo': 'documento'
                }
        
        return None
    
    def baixar_documento(self, url_documento: str, caminho_destino: str) -> bool:
        """
        Baixa um documento do processo
        
        Args:
            url_documento: URL do documento
            caminho_destino: Caminho onde salvar o arquivo
        
        Returns:
            True se sucesso, False caso contrário
        """
        try:
            logger.info(f"Baixando documento: {url_documento}")
            
            response = self.session.get(url_documento, timeout=60)
            
            if response.status_code == 200:
                with open(caminho_destino, 'wb') as f:
                    f.write(response.content)
                
                logger.info(f"✅ Documento salvo em: {caminho_destino}")
                return True
            else:
                logger.error(f"❌ Erro {response.status_code} ao baixar documento")
                return False
                
        except Exception as e:
            logger.error(f"❌ Erro ao baixar documento: {str(e)}")
            return False


def testar_pje():
    """Função de teste do PJe"""
    
    print("🧪 Testando Consulta Pública PJe")
    print("=" * 60)
    
    pje = PJeConsultaPublica(tribunal="TJMG")
    
    # Teste com número de exemplo
    numero_teste = "5000000-00.2024.8.13.0024"
    
    print(f"\n📋 Buscando processo: {numero_teste}")
    processo = pje.buscar_processo(numero_teste)
    
    if processo and 'erro' not in processo:
        print(f"\n✅ Processo encontrado:")
        print(f"   Classe: {processo.get('classe')}")
        print(f"   Assunto: {processo.get('assunto')}")
        print(f"   Autor: {processo.get('partes', {}).get('autor')}")
        print(f"   Réu: {processo.get('partes', {}).get('reu')}")
        print(f"   Movimentações: {len(processo.get('movimentacoes', []))}")
        print(f"   Documentos: {len(processo.get('documentos', []))}")
        print(f"   Tem sentença: {processo.get('tem_sentenca')}")
        
        if processo.get('sentenca'):
            print(f"\n📄 Sentença:")
            print(f"   {processo['sentenca']}")
    else:
        print("⚠️ Processo não encontrado ou erro na consulta")
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    testar_pje()

