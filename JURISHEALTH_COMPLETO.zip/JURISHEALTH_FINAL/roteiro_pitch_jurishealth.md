# Roteiro de Pitch - JurisHealth
## Apresentação para Investidores (10 minutos)

---

## SLIDE 1: ABERTURA (30 segundos)

**[Mostrar logo JurisHealth]**

"Boa tarde! Meu nome é [NOME] e estou aqui para apresentar a **JurisHealth**, uma plataforma que está transformando um mercado de R$ 2,7 bilhões praticamente inexplorado: a conexão entre decisões judiciais de saúde e hospitais privados."

**Gancho emocional:**
"Imagine um paciente com câncer que ganhou na justiça o direito a uma cirurgia urgente. O Estado tem a obrigação de pagar, mas não sabe onde fazer. Hospitais privados têm capacidade ociosa, mas não sabem dessas oportunidades. A JurisHealth resolve esse problema usando inteligência artificial."

---

## SLIDE 2: O PROBLEMA (1 minuto)

**[Mostrar estatísticas do mercado]**

"O Brasil vive uma explosão de judicialização da saúde:

- **870 mil processos ativos** contra o SUS
- **Crescimento de 93,4%** nos últimos 4 anos
- **R$ 2,7 bilhões** gastos pela União anualmente

Quando um paciente ganha na justiça, o Estado precisa contratar hospitais privados para executar o procedimento. Mas hoje esse processo é caótico:

**Para os hospitais:**
- Não têm acesso estruturado a essas oportunidades
- Perdem receita por falta de informação
- Capacidade ociosa desperdiçada

**Para os entes públicos:**
- Dificuldade em encontrar prestadores qualificados
- Processos burocráticos e lentos
- Risco de descumprimento de decisões judiciais

**Para os pacientes:**
- Atrasos na execução de tratamentos urgentes
- Sofrimento prolongado mesmo após ganhar na justiça

É um mercado de bilhões, completamente fragmentado e ineficiente."

---

## SLIDE 3: A SOLUÇÃO (1 minuto 30 segundos)

**[Demonstrar a plataforma]**

"A JurisHealth é uma plataforma SaaS que conecta hospitais a oportunidades de procedimentos médicos com **pagamento garantido por decisão judicial**.

**Como funciona:**

**1. Captura Inteligente**
- Nossa IA monitora 90+ tribunais brasileiros 24/7
- Identifica processos de saúde já ganhos ou em fase final
- Extrai informações estruturadas: procedimento, localização, prazos, valores

**2. Estruturação de Dados**
- Classificamos por especialidade médica
- Estimamos valores baseados em tabelas CBHPM e ANS
- Priorizamos por urgência e prazo judicial

**3. Conexão com Hospitais**
- Dashboard intuitivo mostra oportunidades relevantes
- Hospitais filtram por região, especialidade e valor
- Sistema facilita envio de orçamentos

**4. Dois Modelos de Serviço**
- **Plano Standard (R$ 7.000/mês):** Acesso à plataforma, hospital usa jurídico próprio
- **Plano Premium (R$ 8.400/mês):** Plataforma + nossa equipe jurídica acompanha todo o processo

**O diferencial:** Pagamento garantido. Não é uma oportunidade comercial comum - é uma decisão judicial que obriga o Estado a pagar."

---

## SLIDE 4: MODELO DE NEGÓCIO (1 minuto)

**[Mostrar estrutura de receita]**

"Nosso modelo é **SaaS B2B com receita recorrente**:

**Público-alvo:**
- 6.600 hospitais no Brasil
- 1.000 hospitais qualificados (médio/grande porte, especialidades adequadas)
- Foco inicial: Sudeste (SP, MG, RJ)

**Precificação:**
- Ticket médio: **R$ 7.700/mês**
- Contrato mínimo: 12 meses
- Mix: 60% Standard / 40% Premium

**Por que os hospitais pagam?**
- ROI claro: Um único procedimento pode gerar R$ 50 mil de receita
- Custo de oportunidade: Estão perdendo essas oportunidades hoje
- Eficiência: Nossa plataforma economiza tempo da equipe comercial/jurídica

**Mercado endereçável:**
- TAM: R$ 92,4 milhões/ano
- SAM: R$ 18,5 milhões/ano
- SOM (Ano 3): R$ 3,7 milhões/ano"

---

## SLIDE 5: TRAÇÃO E VALIDAÇÃO (45 segundos)

**[Mostrar MVP e métricas]**

"Já temos tração técnica e validação de mercado:

**Produto:**
- ✅ MVP funcional desenvolvido e testado
- ✅ IA capaz de processar milhares de processos/dia
- ✅ Integração com 5 tribunais principais funcionando

**Mercado:**
- ✅ 15 conversas com diretores de hospitais (validação de dor)
- ✅ 3 cartas de intenção de compra
- ✅ Dados reais de 870 mil processos ativos

**Tecnologia:**
- ✅ Algoritmos de NLP treinados especificamente para processos de saúde
- ✅ Conformidade LGPD desde o design
- ✅ Arquitetura escalável (cloud AWS)"

---

## SLIDE 6: PROJEÇÕES FINANCEIRAS (1 minuto)

**[Mostrar gráficos de crescimento]**

"Nossas projeções são conservadoras e baseadas em benchmarks de SaaS B2B:

**Ano 1:**
- 5 clientes
- R$ 462 mil de receita
- Investimento em produto e primeiras vendas

**Ano 2:**
- 20 clientes
- R$ 1,85 milhão de receita
- **Break-even**

**Ano 3:**
- 40 clientes
- R$ 3,70 milhões de receita
- R$ 2,25 milhões de lucro
- Margem EBITDA: 61%

**Métricas-chave:**
- CAC: R$ 15 mil
- LTV: R$ 185 mil
- LTV/CAC: **12,3x**
- Churn: 2% mensal (Ano 2)
- Payback: 10 meses

Estamos sendo conservadores: capturando apenas 4% do mercado endereçável em 3 anos."

---

## SLIDE 7: VANTAGENS COMPETITIVAS (45 segundos)

**[Mostrar diferenciais]**

"Por que a JurisHealth vai vencer?

**1. Especialização Vertical**
- Foco 100% em judicialização da saúde
- Conhecimento profundo do setor (jurídico + saúde + tecnologia)

**2. Tecnologia Proprietária**
- IA treinada especificamente para processos de saúde
- 2 anos de vantagem sobre potenciais concorrentes

**3. Network Effects**
- Quanto mais hospitais, mais dados
- Quanto mais dados, melhor a IA
- Ciclo virtuoso de melhoria contínua

**4. Barreiras de Entrada**
- Complexidade técnica (IA + jurídico + saúde)
- Conformidade regulatória (LGPD, ANS, CFM)
- Relacionamento com hospitais

**5. Timing Perfeito**
- Judicialização crescendo 93,4% ao ano
- Digitalização dos tribunais acelerando
- Hospitais buscando novas fontes de receita pós-pandemia"

---

## SLIDE 8: ROADMAP E EXPANSÃO (45 segundos)

**[Mostrar visão de futuro]**

"Nossa visão vai além da plataforma inicial:

**Curto Prazo (12 meses):**
- Cobertura nacional (90+ tribunais)
- App mobile para gestores hospitalares
- Módulo de analytics preditivos

**Médio Prazo (24 meses):**
- Marketplace de fornecedores (medicamentos, equipamentos)
- API aberta para ERPs hospitalares
- Expansão para processos trabalhistas

**Longo Prazo (36+ meses):**
- Módulo B2G (entes públicos como clientes)
- Internacionalização (América Latina)
- White-label para redes hospitalares

**Oportunidades de monetização adicional:**
- Comissões no marketplace
- Dados e insights de mercado
- Consultoria estratégica"

---

## SLIDE 9: TIME E INVESTIMENTO (1 minuto)

**[Apresentar fundadores e ask]**

"**Nosso Time:**
- [CEO]: [Background em tecnologia/saúde, experiência em startups]
- [CTO]: [Especialista em IA/ML, arquitetura de software escalável]
- Conselheiros: [Executivo hospitalar + Advogado especialista em saúde + Investidor/mentor]

**O Pedido:**
- **Investimento Seed: R$ 500 mil**
- **Valuation pré-money: R$ 2 milhões**
- **Equity oferecido: 20%**

**Uso do Capital:**
- 36% - Equipe (6 meses runway para 5 pessoas)
- 30% - Desenvolvimento de produto (MVP robusto)
- 20% - Marketing e vendas (primeiros 10 clientes)
- 14% - Infraestrutura, jurídico, reserva

**Retorno Projetado:**
- **7x a 15x em 3-5 anos**
- Série A em 18 meses (R$ 3 milhões, valuation R$ 12 milhões)
- Exit potencial: Aquisição por healthtech, legaltech ou rede hospitalar"

---

## SLIDE 10: FECHAMENTO (30 segundos)

**[Call to action]**

"Para resumir:

✅ **Mercado bilionário** e crescendo 93% ao ano  
✅ **Problema real** validado com hospitais  
✅ **Solução tecnológica** já funcionando  
✅ **Modelo de negócio** recorrente e escalável  
✅ **Time** com expertise única (tech + jurídico + saúde)  
✅ **Retorno** atrativo para investidores (7-15x)

A JurisHealth está na interseção de três megatendências: judicialização da saúde, digitalização do judiciário e transformação digital hospitalar.

**Estamos prontos para escalar. Você está conosco?**

Obrigado! Perguntas?"

---

## PERGUNTAS FREQUENTES (Preparação)

### 1. "Por que os hospitais não fazem isso sozinhos?"

"Excelente pergunta. Três razões:

1. **Complexidade técnica:** Monitorar 90 tribunais, processar milhares de documentos com IA, manter conformidade LGPD - isso exige um time especializado
2. **Escala:** Um hospital sozinho só se interessa pela sua região. Nossa plataforma agrega oportunidades de todo o Brasil
3. **Custo:** Construir isso internamente custaria R$ 2-3 milhões. Nosso SaaS custa R$ 7 mil/mês"

### 2. "E se o governo criar uma plataforma pública?"

"Seria ótimo para o mercado! Mas:

1. **Histórico:** O governo é lento para inovar (PJe levou 10 anos)
2. **Nosso diferencial:** Não somos apenas um portal de dados - oferecemos IA, analytics, suporte jurídico
3. **Pivô possível:** Se isso acontecer, podemos vender para o próprio governo (B2G) ou focar em valor agregado"

### 3. "Qual o maior risco?"

"Mudança regulatória que restrinja acesso a dados públicos. Mitigação:

1. Trabalhamos apenas com dados públicos (Lei de Acesso à Informação)
2. Diversificação de fontes (não dependemos de um tribunal)
3. Parcerias estratégicas com associações hospitalares
4. Lobby setorial para manter transparência"

### 4. "Por que agora?"

"Três catalisadores:

1. **Judicialização explodindo:** +93% em 4 anos
2. **Digitalização dos tribunais:** PJe facilita acesso a dados
3. **Hospitais pós-pandemia:** Buscando novas fontes de receita

A janela de oportunidade é agora - antes que big techs percebam."

### 5. "Como vão competir com Google/Microsoft?"

"Não vamos competir diretamente:

1. **Especialização vertical:** Eles são horizontais, somos especialistas
2. **Relacionamento:** Conhecemos as dores dos hospitais profundamente
3. **Agilidade:** Podemos pivotar e iterar 10x mais rápido
4. **Exit:** Se eles entrarem, somos candidatos à aquisição"

---

## DICAS DE APRESENTAÇÃO

**Linguagem Corporal:**
- Contato visual com todos os investidores
- Postura confiante mas não arrogante
- Gestos naturais para enfatizar pontos-chave

**Tom de Voz:**
- Entusiasmo genuíno (você acredita nisso!)
- Variação de ritmo (pausas estratégicas)
- Clareza e objetividade

**Storytelling:**
- Comece com caso real (paciente + hospital)
- Use dados para validar, não para entediar
- Termine com visão inspiradora

**Gestão de Tempo:**
- Pratique para ficar em 10 minutos
- Tenha versão de 5 minutos (elevador)
- Tenha versão de 20 minutos (deep dive)

**Materiais de Apoio:**
- Deck em PDF (enviar antes)
- Demo ao vivo (se internet permitir)
- One-pager executivo (deixar com investidores)
- Planilha financeira detalhada (para due diligence)

---

**Boa sorte! 🚀**

---

© 2025 JurisHealth - Roteiro de Pitch v2.0
