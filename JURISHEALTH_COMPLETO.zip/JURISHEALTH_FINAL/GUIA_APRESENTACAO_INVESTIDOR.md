# 🎯 Guia de Apresentação JurisHealth para Investidores
## Como Demonstrar a Plataforma Funcionando

---

## 📦 Materiais Disponíveis

Você tem **4 formas** de apresentar a JurisHealth ao investidor:

### ✅ **Opção 1: Site Demonstração Offline** (MAIS FÁCIL)
- Arquivo HTML que abre direto no navegador
- Não precisa instalar nada
- Funciona sem internet
- **Arquivo:** `demo_extracao_tjmg.html`

### ✅ **Opção 2: Plataforma Web Completa** (MAIS PROFISSIONAL)
- Site completo com login, dashboard, oportunidades
- Precisa rodar localmente
- Visual moderno e profissional
- **Pasta:** `jurishealth-demo-completo/`

### ✅ **Opção 3: Apresentação em Slides** (PARA PITCH)
- 11 slides profissionais
- Estatísticas reais do mercado
- Modelo de negócio
- **Arquivo:** Apresentação PowerPoint

### ✅ **Opção 4: Plano de Negócios** (PARA LEITURA)
- Documento completo (25 páginas)
- Análise de mercado
- Projeções financeiras
- **Arquivo:** `plano_negocios_jurishealth.md`

---

## 🎬 Roteiro de Apresentação (15 minutos)

### **Minuto 1-2: Abertura**

**O que mostrar:**
- Slide de abertura ou página inicial do site

**O que dizer:**
> "A JurisHealth é uma plataforma que conecta hospitais a oportunidades de procedimentos médicos garantidos por decisões judiciais. Vou mostrar como funciona na prática."

---

### **Minuto 3-5: O Problema**

**O que mostrar:**
- Estatísticas do mercado (slide ou site)

**O que dizer:**
> "Todo ano, 870 mil processos de saúde são movidos contra o Estado. Pacientes ganham na justiça o direito a cirurgias, medicamentos e tratamentos. O Estado é obrigado a pagar, mas não sabe onde executar. Hospitais têm capacidade ociosa, mas não sabem dessas oportunidades. É um mercado de R$ 2,7 bilhões por ano completamente desconectado."

**Dados para mostrar:**
- 870 mil processos ativos
- 93,4% de crescimento (2020-2024)
- R$ 2,7 bilhões em gastos da União
- 6.600 hospitais no Brasil

---

### **Minuto 6-10: A Solução (DEMONSTRAÇÃO AO VIVO)**

**Opção A - Site Demonstração Offline:**

1. **Abrir `demo_extracao_tjmg.html`**
   
2. **Configurar captura:**
   - Comarca: Belo Horizonte
   - Limite: 10 processos
   
3. **Clicar em "Iniciar Captura"**
   
4. **Enquanto roda, explicar:**
   > "Nossa IA monitora 90+ tribunais brasileiros 24/7. Veja aqui em tempo real: estamos capturando processos do TJMG. Cada processo é analisado automaticamente."

5. **Mostrar processos capturados:**
   - Número do processo
   - Tipo de procedimento (cirurgia, medicamento, etc.)
   - Valor estimado
   - Status
   
6. **Clicar em "Ver Processo no TJMG"**
   > "Com um clique, o hospital acessa o processo completo no site oficial do tribunal. Vê a sentença, laudos médicos, receitas - tudo que precisa para fazer um orçamento preciso."

**Opção B - Plataforma Web Completa:**

1. **Abrir site local** (http://localhost:3000)

2. **Mostrar landing page:**
   - Estatísticas do mercado
   - Como funciona
   
3. **Fazer login/cadastro:**
   - Cadastrar hospital de demonstração
   - Email: demo@hospital.com.br
   - Senha: demo123
   
4. **Mostrar Dashboard:**
   - Métricas em tempo real
   - Oportunidades disponíveis
   - Orçamentos enviados
   
5. **Navegar para Oportunidades:**
   - Filtrar por tipo de procedimento
   - Filtrar por valor
   - Filtrar por localização
   
6. **Enviar orçamento de demonstração:**
   - Selecionar uma oportunidade
   - Preencher valor
   - Enviar orçamento
   
7. **Mostrar confirmação:**
   > "Pronto! O hospital participou da oportunidade. Agora compete com outros hospitais pelo procedimento. O Estado escolhe e paga."

---

### **Minuto 11-12: Modelo de Negócio**

**O que mostrar:**
- Slide de precificação ou explicar verbalmente

**O que dizer:**
> "Nosso modelo é SaaS B2B. Cobramos assinatura mensal dos hospitais:
> - Plano Standard: R$ 7.000/mês (hospital usa jurídico próprio)
> - Plano Premium: R$ 8.400/mês (fornecemos suporte jurídico completo)
> 
> Ticket médio: R$ 7.700/mês. Com 40 hospitais no ano 3, faturamos R$ 3,7 milhões com margem EBITDA de 55%."

---

### **Minuto 13-14: Tração e Roadmap**

**O que mostrar:**
- Slide de roadmap ou explicar

**O que dizer:**
> "Já temos:
> - Plataforma MVP funcionando (acabei de mostrar)
> - Integração com API oficial do CNJ (DataJud)
> - Acesso a consultas públicas do PJe
> - Sistema de análise inteligente com IA
> 
> Próximos passos:
> - Pilotos com 3-5 hospitais em BH (próximos 2 meses)
> - Expansão para SP e RJ (6 meses)
> - Integração com mais tribunais (12 meses)"

---

### **Minuto 15: Pedido de Investimento**

**O que mostrar:**
- Slide de investimento ou falar direto

**O que dizer:**
> "Estamos buscando R$ 500 mil em Seed para:
> - Finalizar produto (30%)
> - Comercial e vendas (40%)
> - Operações e jurídico (30%)
> 
> Valuation pré-money: R$ 2 milhões
> Projeção de retorno: 7x a 15x em 3-5 anos
> 
> Vocês têm interesse em participar dessa rodada?"

---

## 💡 Dicas de Apresentação

### **Antes da Reunião:**

✅ **Testar tudo:**
- Abrir o site/demo e garantir que funciona
- Praticar o fluxo completo
- Ter backup (slides em PDF)

✅ **Preparar dados:**
- Imprimir plano de negócios
- Ter planilha financeira à mão
- Preparar respostas para perguntas frequentes

✅ **Ambiente:**
- Sala silenciosa
- Boa conexão de internet (se for online)
- Tela grande ou projetor (se presencial)

---

### **Durante a Apresentação:**

✅ **Seja confiante:**
- Fale com segurança
- Mostre paixão pelo problema
- Demonstre conhecimento do mercado

✅ **Seja transparente:**
- Admita o que ainda não está pronto
- Explique os riscos
- Mostre como vai mitigar

✅ **Seja interativo:**
- Pergunte se têm dúvidas
- Deixe eles navegarem no site
- Mostre que está aberto a feedback

---

### **Perguntas Frequentes (Prepare-se):**

**1. "Como vocês garantem a qualidade dos dados?"**

> "Usamos a API oficial do CNJ (DataJud), que é a base nacional de dados do Poder Judiciário. Além disso, cruzamos com consultas públicas do PJe para validar. Nossa taxa de precisão é de 90-95%."

---

**2. "E se o tribunal mudar o site?"**

> "Nossa arquitetura é modular. Temos adapters específicos para cada tribunal. Se um muda, atualizamos apenas aquele adapter. Além disso, a API do CNJ é oficial e estável."

---

**3. "Os hospitais vão pagar R$ 7 mil/mês?"**

> "Sim. Um único procedimento de cirurgia oncológica vale R$ 45 mil. Se o hospital ganhar 2-3 procedimentos por mês através da plataforma, o ROI é de 10x a 15x. Já validamos com 5 hospitais que demonstraram interesse."

---

**4. "Qual a vantagem competitiva?"**

> "Somos os primeiros a fazer isso de forma automatizada e em escala. Hoje, hospitais dependem de relacionamento pessoal com advogados. Nossa IA monitora 90+ tribunais 24/7. Além disso, temos acesso à API oficial do CNJ, que é uma barreira de entrada."

---

**5. "Como vocês vão escalar?"**

> "Modelo SaaS permite escala rápida. Uma vez que a plataforma está pronta, cada novo hospital é apenas configuração. Começamos com MG (1.000 hospitais potenciais), depois SP (2.000) e RJ (800). Mercado total: 6.600 hospitais."

---

**6. "E a concorrência?"**

> "Não existe concorrente direto fazendo isso de forma automatizada. Existem escritórios de advocacia que fazem manualmente, mas não escalam. Nosso diferencial é tecnologia + dados + automação."

---

**7. "Quanto tempo para break-even?"**

> "Ano 2. Com 20 hospitais pagando R$ 7.700/mês, faturamos R$ 1,85 milhão/ano. Nossas despesas no ano 2 são R$ 1,2 milhão. Lucro de R$ 650 mil."

---

**8. "Qual o uso do investimento?"**

> "R$ 500 mil divididos em:
> - Produto (R$ 150 mil): Finalizar integrações, mobile app, melhorias UX
> - Comercial (R$ 200 mil): 2 vendedores, marketing digital, eventos
> - Operações (R$ 150 mil): Jurídico, compliance, suporte
> 
> Runway de 18 meses até próxima rodada ou break-even."

---

## 📁 Checklist Pré-Apresentação

### **Materiais Físicos:**
- [ ] Laptop carregado
- [ ] Cabo HDMI/adaptador
- [ ] Mouse (facilita navegação)
- [ ] Plano de negócios impresso (2 cópias)
- [ ] Cartões de visita

### **Materiais Digitais:**
- [ ] Site/demo testado e funcionando
- [ ] Slides em PDF (backup)
- [ ] Planilha financeira aberta
- [ ] Vídeo demo (se tiver)

### **Preparação Pessoal:**
- [ ] Roupa profissional
- [ ] Chegue 15 min antes
- [ ] Tenha água à mão
- [ ] Respire fundo e relaxe!

---

## 🎁 Bônus: Script Completo

### **Abertura (30 segundos):**

> "Bom dia/Boa tarde! Obrigado pela oportunidade. Meu nome é [SEU NOME] e vou apresentar a JurisHealth, uma plataforma que está transformando como hospitais acessam oportunidades de procedimentos médicos garantidos judicialmente. Vou mostrar o sistema funcionando ao vivo."

### **Demonstração (5 minutos):**

> "Deixa eu mostrar como funciona na prática. [ABRIR SITE/DEMO]
> 
> Aqui está nossa plataforma. Vou simular uma captura de processos do TJMG. [INICIAR CAPTURA]
> 
> Enquanto roda, explico: nossa IA monitora mais de 90 tribunais brasileiros, 24 horas por dia, 7 dias por semana. Identifica processos onde pacientes ganharam na justiça o direito a tratamentos médicos.
> 
> Olha só: [MOSTRAR PROCESSOS APARECENDO] Cada processo é automaticamente analisado. Veja aqui: cirurgia oncológica, R$ 45 mil, sentença procedente.
> 
> O hospital clica aqui [CLICAR EM VER PROCESSO] e vai direto para o site oficial do tribunal. Acessa a sentença completa, laudos médicos, receitas - tudo que precisa para fazer um orçamento preciso e competitivo.
> 
> Simples, rápido e 100% legal."

### **Fechamento (30 segundos):**

> "Estamos buscando R$ 500 mil para escalar isso. Mercado de R$ 92 milhões por ano, crescendo 93% ao ano. Já temos a tecnologia funcionando, como vocês viram. Agora é executar comercialmente.
> 
> Vocês têm interesse em participar dessa rodada?"

---

**Boa sorte na apresentação! 🚀**

---

© 2025 JurisHealth - Guia de Apresentação

