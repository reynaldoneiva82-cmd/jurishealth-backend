# Plano de Negócios - JurisHealth

## Plataforma de Inteligência para Oportunidades Judiciais de Saúde

---

## 1. Resumo Executivo

A **JurisHealth** é uma plataforma de tecnologia jurídica (legaltech) especializada em conectar hospitais privados a oportunidades de procedimentos médicos oriundos de processos judiciais ganhos contra entes públicos. Utilizando inteligência artificial e análise de dados jurídicos, a JurisHealth captura, estrutura e disponibiliza informações sobre decisões judiciais que obrigam o Estado e municípios a fornecerem tratamentos de saúde que o SUS não consegue absorver, permitindo que hospitais privados participem ativamente desse mercado com pagamento garantido por decisão judicial.

### Problema

O Brasil enfrenta uma crescente judicialização da saúde, com **870 mil processos ativos** e crescimento de **93,4% entre 2020-2024**. Quando pacientes ganham na justiça o direito a procedimentos que o SUS não pode realizar, o Estado precisa contratar hospitais privados. Atualmente, esse processo é fragmentado, ineficiente e opaco, resultando em:

- **Hospitais privados** não têm acesso estruturado a essas oportunidades de negócio
- **Entes públicos** enfrentam dificuldades para encontrar prestadores qualificados rapidamente
- **Pacientes** sofrem atrasos na execução de decisões judiciais já ganhas
- **Desperdício de recursos** estimado em R$ 2,7 bilhões anuais pela União

### Solução

A JurisHealth oferece uma plataforma SaaS (Software as a Service) que:

1. **Captura automaticamente** processos judiciais de saúde usando IA e web scraping em mais de 90 tribunais brasileiros
2. **Estrutura dados** relevantes: tipo de procedimento, localização, prazos, valores estimados
3. **Conecta hospitais** às oportunidades através de dashboard intuitivo
4. **Facilita orçamentos** com dois modelos de serviço (com ou sem suporte jurídico)
5. **Garante conformidade** com LGPD e regulamentações do setor de saúde

### Modelo de Negócio

**Receita recorrente (SaaS)** através de assinaturas mensais para hospitais:

- **Plano Standard:** R$ 7.000/mês (hospital usa jurídico próprio)
- **Plano Premium:** R$ 8.400/mês (JurisHealth fornece suporte jurídico completo)
- **Ticket médio:** R$ 7.700/mês

**Público-alvo:** Hospitais privados e filantrópicos de médio e grande porte (6.600 no Brasil, 1.000 qualificados como clientes potenciais)

### Tração e Validação

- Plataforma MVP desenvolvida e testada
- Modelo de negócio validado com dados reais de mercado
- Tecnologia comprovada (IA, NLP, web scraping)
- Mercado endereçável de R$ 92,4 milhões anuais

### Investimento e Projeções

**Investimento Seed:** R$ 500 mil  
**Valuation pré-money:** R$ 2 milhões  
**Equity oferecido:** 20%

**Projeções financeiras (3 anos):**
- **Ano 1:** R$ 462 mil de receita | 5 clientes
- **Ano 2:** R$ 1,85 milhão de receita | 20 clientes | Break-even
- **Ano 3:** R$ 3,70 milhões de receita | 40 clientes | R$ 2,25 milhões de lucro

**Retorno projetado:** 7x a 15x em 3-5 anos

---

## 2. Descrição Detalhada do Produto

### 2.1 Visão Geral

A JurisHealth é uma plataforma web que atua como marketplace inteligente entre decisões judiciais de saúde e hospitais privados. O sistema monitora continuamente tribunais brasileiros, identifica processos relevantes e apresenta oportunidades estruturadas para hospitais parceiros.

### 2.2 Funcionalidades Principais

#### A. Captura Inteligente de Processos

**Tecnologia:**
- Web scraping automatizado em 90+ tribunais (TJMG, TJSP, TJRJ, etc.)
- Processamento de linguagem natural (NLP) para extração de informações
- Machine learning para classificação e priorização
- Monitoramento 24/7 com atualizações em tempo real

**Dados capturados:**
- Número do processo e tribunal
- Tipo de procedimento médico/medicamento
- Município e comarca
- Prazos judiciais
- Valores estimados
- Status do processo (transitado em julgado, em execução, etc.)
- Hash anônimo do paciente (conformidade LGPD)

#### B. Dashboard para Hospitais

**Recursos:**
- Visualização de oportunidades por região, especialidade e valor
- Filtros avançados (cidade, procedimento, prazo, valor)
- Sistema de alertas personalizados
- Histórico de orçamentos enviados
- Métricas de performance (taxa de sucesso, receita gerada)
- Gestão de documentação e credenciais

#### C. Sistema de Orçamentos

**Fluxo:**
1. Hospital visualiza oportunidade detalhada
2. Prepara orçamento com valores e prazos
3. Submete através da plataforma
4. Acompanha status (submetido, em análise, ganho, perdido)
5. Recebe notificações de atualizações

**Diferenciais:**
- Templates de orçamento padronizados
- Integração com tabelas CBHPM e ANS
- Histórico de preços de mercado
- Sugestões baseadas em IA

#### D. Suporte Jurídico (Plano Premium)

**Serviços inclusos:**
- Análise jurídica do processo
- Elaboração de peças processuais
- Acompanhamento de prazos
- Inserção de orçamentos no sistema judicial
- Suporte em audiências e diligências
- Consultoria regulatória

### 2.3 Arquitetura Técnica

**Backend:**
- Python 3.11+ com FastAPI
- PostgreSQL para dados estruturados
- Redis para cache e filas
- Celery para tarefas assíncronas

**Frontend:**
- React 19 com TypeScript
- Tailwind CSS para UI responsiva
- shadcn/ui para componentes

**Infraestrutura:**
- Cloud AWS (escalabilidade e segurança)
- CI/CD automatizado
- Backup diário e disaster recovery
- Monitoramento com Datadog

**Segurança:**
- Autenticação JWT
- Criptografia end-to-end
- Conformidade LGPD
- Auditoria completa de acessos
- Rate limiting e proteção DDoS

### 2.4 Diferenciais Competitivos

1. **Especialização vertical:** Foco exclusivo em judicialização da saúde
2. **Cobertura nacional:** Monitoramento de 90+ tribunais
3. **IA proprietária:** Algoritmos treinados especificamente para processos de saúde
4. **Modelo híbrido:** Plataforma + serviço jurídico opcional
5. **Time-to-market:** Hospitais acessam oportunidades em tempo real
6. **ROI mensurável:** Métricas claras de performance e receita gerada

---

## 3. Análise de Mercado

### 3.1 Tamanho do Mercado

**Judicialização da Saúde no Brasil:**
- **870 mil processos ativos** (CNJ, 2024)
- **Crescimento de 93,4%** entre 2020-2024
- **R$ 2,7 bilhões** gastos anuais da União
- **345 mil novas ações** em 2024 (estimativa)

**Mercado Hospitalar:**
- **6.600 hospitais** no Brasil
- **1.000 hospitais qualificados** (médio/grande porte, especialidades adequadas)
- **Faturamento hospitalar privado:** R$ 180 bilhões/ano

**Mercado Endereçável (TAM/SAM/SOM):**
- **TAM:** R$ 92,4 milhões/ano (1.000 hospitais × R$ 7.700/mês)
- **SAM:** R$ 18,5 milhões/ano (200 hospitais early adopters)
- **SOM (Ano 3):** R$ 3,7 milhões/ano (40 hospitais)

### 3.2 Tendências de Mercado

**Crescimento da Judicialização:**
- Envelhecimento populacional (aumento de doenças crônicas)
- Incorporação de novas tecnologias médicas caras
- Maior conscientização sobre direitos à saúde
- Atuação de escritórios especializados em saúde

**Digitalização do Judiciário:**
- PJe (Processo Judicial Eletrônico) em expansão
- Dados públicos mais acessíveis
- Tribunais investindo em transparência

**Transformação Digital da Saúde:**
- Hospitais buscando novas fontes de receita
- Adoção de tecnologia para gestão
- Pressão por eficiência operacional

### 3.3 Análise Competitiva

**Concorrentes Diretos:** Não identificados (nicho inexplorado)

**Concorrentes Indiretos:**

| Empresa | Foco | Diferencial JurisHealth |
|---------|------|------------------------|
| Jusbrasil | Busca jurídica genérica | Especialização em saúde + IA |
| Judit.io | Dados jurídicos B2B | Foco em hospitais, não advogados |
| Escavador | Monitoramento de processos | Estruturação para ação comercial |
| Consultórios jurídicos | Serviço manual | Automação + escala |

**Barreiras de Entrada:**
- Tecnologia complexa (IA + jurídico + saúde)
- Conhecimento especializado do setor
- Relacionamento com hospitais
- Conformidade regulatória (LGPD, ANS, CFM)

### 3.4 Público-Alvo Detalhado

**Perfil do Cliente Ideal (ICP):**

**Hospitais Privados de Médio/Grande Porte:**
- 100+ leitos
- Faturamento anual acima de R$ 50 milhões
- Especialidades: oncologia, cardiologia, neurologia, ortopedia
- Credenciados ANS e com tabela CBHPM
- Localização: capitais e cidades médias (100k+ habitantes)

**Dores específicas:**
- Ociosidade de capacidade instalada
- Dificuldade em acessar contratos públicos
- Falta de previsibilidade de demanda
- Processos comerciais ineficientes

**Ganhos esperados:**
- Nova fonte de receita recorrente
- Pagamento garantido (decisão judicial)
- Otimização de capacidade ociosa
- Diversificação de carteira de clientes

---

## 4. Estratégia de Go-to-Market

### 4.1 Estratégia de Aquisição

**Fase 1 - Validação (Meses 1-6):**
- **Outbound direto:** Abordagem personalizada a 50 hospitais selecionados
- **Parcerias estratégicas:** Associações hospitalares (ANAHP, CMB)
- **Eventos do setor:** Congressos de gestão hospitalar
- **Pilotos gratuitos:** 3-5 hospitais para validação e cases

**Fase 2 - Escala (Meses 7-18):**
- **Inbound marketing:** SEO, conteúdo especializado, webinars
- **Inside sales:** Time SDR + Closer
- **Indicações:** Programa de referral para clientes
- **Parcerias comerciais:** Consultorias de gestão hospitalar

**Fase 3 - Expansão (Meses 19-36):**
- **Account-based marketing:** Grandes redes hospitalares
- **Canais de distribuição:** Revendedores especializados
- **Expansão geográfica:** Priorização por estados

### 4.2 Estratégia de Precificação

**Modelo Value-Based:**
- Preço baseado no valor gerado (acesso a oportunidades de alto valor)
- Custo de aquisição de cliente (CAC) alvo: R$ 15.000
- Lifetime Value (LTV) projetado: R$ 185.000 (24 meses)
- Razão LTV/CAC: 12,3x

**Estrutura de Planos:**

| Plano | Preço/mês | Recursos | Público |
|-------|-----------|----------|---------|
| Standard | R$ 7.000 | Plataforma completa, hospital usa jurídico próprio | Hospitais com equipe jurídica |
| Premium | R$ 8.400 | Plataforma + suporte jurídico JurisHealth | Hospitais sem jurídico especializado |

**Política Comercial:**
- Contrato mínimo: 12 meses
- Desconto anual: 10% (pagamento à vista)
- Setup fee: Isento nos primeiros 50 clientes
- Trial: 30 dias com acesso limitado

### 4.3 Funil de Vendas

**Ciclo de venda estimado:** 45-60 dias

1. **Prospecção (Semana 1-2)**
   - Identificação de decisores (diretores comerciais, CFOs)
   - Primeiro contato (email + LinkedIn)
   - Qualificação BANT

2. **Descoberta (Semana 3)**
   - Reunião de diagnóstico
   - Apresentação da plataforma
   - Demonstração personalizada

3. **Proposta (Semana 4-5)**
   - Envio de proposta comercial
   - Análise de ROI personalizada
   - Negociação de condições

4. **Fechamento (Semana 6-8)**
   - Aprovação jurídica/compliance
   - Assinatura de contrato
   - Onboarding e treinamento

**Métricas de Conversão:**
- Lead → Oportunidade: 30%
- Oportunidade → Proposta: 50%
- Proposta → Fechamento: 40%
- **Conversão total:** 6%

---

## 5. Plano Operacional

### 5.1 Estrutura Organizacional

**Ano 1 (5 pessoas):**
- 1 CEO/Founder (tecnologia + produto)
- 1 CTO/Co-founder (desenvolvimento)
- 1 Head de Vendas (comercial + parcerias)
- 1 Analista Jurídico (compliance + conteúdo)
- 1 Customer Success (onboarding + suporte)

**Ano 2 (12 pessoas):**
- +2 Desenvolvedores
- +2 SDRs (vendas)
- +1 Advogado Sênior (serviço premium)
- +1 Analista de Dados/IA
- +1 Designer UX/UI

**Ano 3 (20 pessoas):**
- +3 Desenvolvedores
- +2 Closers (vendas)
- +2 Advogados (serviço premium)
- +1 Head de Marketing

### 5.2 Processos-Chave

**Desenvolvimento de Produto:**
- Sprints quinzenais (metodologia ágil)
- Roadmap trimestral baseado em feedback
- Testes A/B contínuos
- Deploy semanal de melhorias

**Operação de Captura:**
- Monitoramento 24/7 automatizado
- Revisão humana de casos complexos
- Atualização de algoritmos mensalmente
- SLA: 95% de uptime

**Atendimento ao Cliente:**
- Onboarding em 5 dias úteis
- Suporte via chat (horário comercial)
- SLA de resposta: 4 horas
- NPS trimestral

**Serviço Jurídico (Premium):**
- Análise de processo em 48h
- Elaboração de orçamento em 72h
- Acompanhamento semanal de status
- Relatórios mensais de performance

### 5.3 Tecnologia e Infraestrutura

**Stack Tecnológico:**
- Linguagens: Python, TypeScript, SQL
- Frameworks: FastAPI, React, TailwindCSS
- Banco de dados: PostgreSQL, Redis
- Cloud: AWS (EC2, RDS, S3, Lambda)
- IA/ML: spaCy, scikit-learn, Hugging Face

**Custos de Infraestrutura:**
- Ano 1: R$ 3.000/mês (AWS, ferramentas)
- Ano 2: R$ 8.000/mês (escala)
- Ano 3: R$ 15.000/mês (alta disponibilidade)

---

## 6. Plano Financeiro

### 6.1 Premissas

**Receita:**
- Ticket médio: R$ 7.700/mês
- Mix de planos: 60% Standard / 40% Premium
- Churn mensal: 3% (Ano 1), 2% (Ano 2), 1,5% (Ano 3)
- Crescimento de clientes: 5 (Ano 1) → 20 (Ano 2) → 40 (Ano 3)

**Custos:**
- Salários: Média R$ 12.000/mês por colaborador
- Infraestrutura: Crescimento proporcional à base
- Marketing/Vendas: 30% da receita
- Jurídico (Premium): R$ 2.500/cliente/mês

### 6.2 Demonstrativo de Resultados (DRE) - 3 Anos

| Item | Ano 1 | Ano 2 | Ano 3 |
|------|-------|-------|-------|
| **RECEITA BRUTA** | R$ 462.000 | R$ 1.848.000 | R$ 3.696.000 |
| (-) Impostos (13,33%) | R$ 61.585 | R$ 246.258 | R$ 492.517 |
| **RECEITA LÍQUIDA** | R$ 400.415 | R$ 1.601.742 | R$ 3.203.483 |
| | | | |
| **CUSTOS VARIÁVEIS** | | | |
| Serviço Jurídico Premium | R$ 60.000 | R$ 240.000 | R$ 480.000 |
| Infraestrutura Cloud | R$ 36.000 | R$ 96.000 | R$ 180.000 |
| **Total Custos Variáveis** | R$ 96.000 | R$ 336.000 | R$ 660.000 |
| | | | |
| **MARGEM DE CONTRIBUIÇÃO** | R$ 304.415 | R$ 1.265.742 | R$ 2.543.483 |
| **% Margem** | 76,0% | 79,0% | 79,4% |
| | | | |
| **CUSTOS FIXOS** | | | |
| Salários + Encargos | R$ 720.000 | R$ 1.728.000 | R$ 2.880.000 |
| Marketing e Vendas | R$ 138.600 | R$ 554.400 | R$ 1.108.800 |
| Administrativo | R$ 60.000 | R$ 120.000 | R$ 180.000 |
| **Total Custos Fixos** | R$ 918.600 | R$ 2.402.400 | R$ 4.168.800 |
| | | | |
| **EBITDA** | **(R$ 614.185)** | **(R$ 1.136.658)** | **(R$ 1.625.317)** |
| **% EBITDA** | -153,4% | -70,9% | -49,3% |
| | | | |
| Depreciação | R$ 20.000 | R$ 40.000 | R$ 60.000 |
| **LUCRO OPERACIONAL** | **(R$ 634.185)** | **(R$ 1.176.658)** | **(R$ 1.685.317)** |
| | | | |
| Receita Financeira | R$ 15.000 | R$ 30.000 | R$ 50.000 |
| **LUCRO LÍQUIDO** | **(R$ 619.185)** | **(R$ 1.146.658)** | **(R$ 1.635.317)** |

**Observação:** Os valores negativos indicam investimento necessário para crescimento. O break-even está projetado para o Ano 2 com 20 clientes.

### 6.3 Fluxo de Caixa - 3 Anos

| Item | Ano 1 | Ano 2 | Ano 3 |
|------|-------|-------|-------|
| **Saldo Inicial** | R$ 500.000 | **(R$ 119.185)** | **(R$ 1.265.843)** |
| | | | |
| **Entradas** | | | |
| Receita Operacional | R$ 462.000 | R$ 1.848.000 | R$ 3.696.000 |
| Investimento Seed | R$ 500.000 | - | - |
| **Total Entradas** | R$ 962.000 | R$ 1.848.000 | R$ 3.696.000 |
| | | | |
| **Saídas** | | | |
| Custos Variáveis | R$ 96.000 | R$ 336.000 | R$ 660.000 |
| Custos Fixos | R$ 918.600 | R$ 2.402.400 | R$ 4.168.800 |
| Impostos | R$ 61.585 | R$ 246.258 | R$ 492.517 |
| Investimentos (capex) | R$ 5.000 | R$ 10.000 | R$ 15.000 |
| **Total Saídas** | R$ 1.081.185 | R$ 2.994.658 | R$ 5.336.317 |
| | | | |
| **Saldo Final** | **(R$ 119.185)** | **(R$ 1.265.843)** | **(R$ 2.906.160)** |

**Necessidade de Capital Adicional:**
- Ano 2: R$ 1,3 milhão (Série A)
- Ano 3: R$ 1,7 milhão (extensão Série A ou Série B)

### 6.4 Uso do Investimento Seed (R$ 500 mil)

| Categoria | Valor | % | Justificativa |
|-----------|-------|---|---------------|
| Desenvolvimento de Produto | R$ 150.000 | 30% | MVP robusto, integrações tribunais |
| Equipe (6 meses runway) | R$ 180.000 | 36% | 5 pessoas nos primeiros 6 meses |
| Marketing e Vendas | R$ 100.000 | 20% | Aquisição primeiros 10 clientes |
| Infraestrutura | R$ 30.000 | 6% | Servidores, ferramentas, licenças |
| Jurídico e Compliance | R$ 20.000 | 4% | Contratos, LGPD, regulatório |
| Reserva Operacional | R$ 20.000 | 4% | Contingências |
| **TOTAL** | **R$ 500.000** | **100%** | |

### 6.5 Indicadores-Chave (KPIs)

| Métrica | Ano 1 | Ano 2 | Ano 3 |
|---------|-------|-------|-------|
| MRR (Receita Recorrente Mensal) | R$ 38.500 | R$ 154.000 | R$ 308.000 |
| ARR (Receita Recorrente Anual) | R$ 462.000 | R$ 1.848.000 | R$ 3.696.000 |
| Clientes Ativos (fim do ano) | 5 | 20 | 40 |
| CAC (Custo de Aquisição) | R$ 27.720 | R$ 27.720 | R$ 27.720 |
| LTV (Lifetime Value) | R$ 185.000 | R$ 277.000 | R$ 308.000 |
| LTV/CAC | 6,7x | 10,0x | 11,1x |
| Churn Mensal | 3,0% | 2,0% | 1,5% |
| Burn Rate Mensal | R$ 51.599 | R$ 95.555 | R$ 135.443 |
| Runway (meses) | 9,7 | 13,2 | 21,5 |

---

## 7. Análise de Riscos

### 7.1 Riscos Identificados

| Risco | Probabilidade | Impacto | Mitigação |
|-------|---------------|---------|-----------|
| **Mudança regulatória** (restrição acesso dados públicos) | Média | Alto | Diversificar fontes, parcerias com tribunais, lobby setorial |
| **Baixa adoção hospitais** (resistência cultural) | Média | Alto | Pilotos gratuitos, cases de sucesso, ROI demonstrável |
| **Concorrência de big techs** (Google, Microsoft) | Baixa | Alto | Especialização vertical, relacionamento próximo, agilidade |
| **Problemas técnicos** (falha scraping, IA imprecisa) | Média | Médio | Redundância, revisão humana, melhoria contínua |
| **Questões jurídicas** (LGPD, acesso à informação) | Baixa | Alto | Compliance rigoroso, assessoria jurídica permanente |
| **Dependência de poucos clientes** | Alta | Médio | Diversificação ativa, contratos escalonados |
| **Dificuldade de contratação** (talentos tech + jurídico) | Média | Médio | Equity para key hires, cultura forte, remote-first |

### 7.2 Plano de Contingência

**Cenário 1: Baixa Tração (< 3 clientes em 6 meses)**
- Pivot para modelo freemium
- Foco em nicho específico (ex: apenas oncologia)
- Parceria estratégica com rede hospitalar

**Cenário 2: Mudança Regulatória Adversa**
- Modelo B2G (venda para entes públicos)
- Expansão para outros tipos de processos (trabalhista, cível)
- Internacionalização (América Latina)

**Cenário 3: Entrada de Concorrente Forte**
- Aceleração de aquisição de clientes (land grab)
- Diferenciação por serviço premium
- Busca de aquisição estratégica

---

## 8. Estratégia de Crescimento e Expansão

### 8.1 Roadmap de Produto (3 anos)

**Ano 1 - Foundation:**
- ✅ MVP funcional (captura + dashboard + orçamentos)
- ✅ Integração com 5 tribunais principais (TJMG, TJSP, TJRJ, TJRS, TJPR)
- Módulo de analytics e relatórios
- App mobile (iOS/Android)

**Ano 2 - Scale:**
- Integração com 90+ tribunais (cobertura nacional)
- IA preditiva (probabilidade de ganho, valores estimados)
- Marketplace de fornecedores (laboratórios, equipamentos)
- API aberta para integrações (ERPs hospitalares)

**Ano 3 - Expansion:**
- Módulo B2G (entes públicos como clientes)
- Expansão para processos trabalhistas e cíveis
- Internacionalização (Argentina, Colômbia, México)
- White-label para redes hospitalares

### 8.2 Estratégia de Expansão Geográfica

**Fase 1 (Ano 1): Sudeste**
- São Paulo, Minas Gerais, Rio de Janeiro
- 60% dos processos de saúde
- Maior concentração de hospitais qualificados

**Fase 2 (Ano 2): Sul + Nordeste**
- Rio Grande do Sul, Paraná, Bahia, Pernambuco
- 25% dos processos
- Hospitais de médio porte

**Fase 3 (Ano 3): Centro-Oeste + Norte**
- Distrito Federal, Goiás, Amazonas, Pará
- 15% dos processos
- Completar cobertura nacional

### 8.3 Oportunidades de Monetização Adicional

1. **Marketplace de Serviços:**
   - Comissão sobre fornecedores (medicamentos, equipamentos)
   - Receita adicional: R$ 500/transação

2. **Dados e Insights:**
   - Relatórios de mercado para investidores
   - Benchmarking para hospitais
   - Receita adicional: R$ 50k/ano

3. **Consultoria Estratégica:**
   - Projetos customizados para redes hospitalares
   - Receita adicional: R$ 100k/projeto

4. **Licenciamento de Tecnologia:**
   - White-label para associações hospitalares
   - Receita adicional: R$ 200k/ano

---

## 9. Time e Governança

### 9.1 Fundadores (a definir)

**CEO - Perfil Ideal:**
- Background: Engenharia/Tecnologia + MBA
- Experiência: Startups B2B SaaS, healthtech ou legaltech
- Habilidades: Visão estratégica, fundraising, liderança

**CTO - Perfil Ideal:**
- Background: Ciência da Computação, especialização em IA/ML
- Experiência: Desenvolvimento de produtos escaláveis, web scraping
- Habilidades: Arquitetura de software, gestão de equipe técnica

### 9.2 Conselheiros e Advisors

**Conselho Consultivo:**
- 1 executivo sênior de rede hospitalar (go-to-market)
- 1 advogado especialista em direito à saúde (compliance)
- 1 investidor/mentor de startups B2B (estratégia)
- 1 especialista em IA/dados jurídicos (tecnologia)

**Equity para advisors:** 0,25% cada (vesting 2 anos)

### 9.3 Governança Corporativa

**Estrutura Societária:**
- Holding + Operacional (otimização tributária)
- Acordo de acionistas robusto
- Vesting de fundadores: 4 anos (cliff 1 ano)
- Pool de opções: 15% (colaboradores-chave)

**Reuniões:**
- Board mensal (fundadores + investidores)
- All-hands quinzenal (toda equipe)
- Retrospectivas trimestrais (OKRs)

---

## 10. Próximos Passos

### 10.1 Milestones Imediatos (6 meses)

| Mês | Objetivo | Métrica de Sucesso |
|-----|----------|-------------------|
| 1 | Fechamento Seed | R$ 500k captados |
| 2 | Contratação time core | 5 pessoas onboarded |
| 3 | MVP em produção | 5 tribunais integrados |
| 4 | Primeiros pilotos | 3 hospitais testando |
| 5 | Validação comercial | 2 contratos pagos |
| 6 | Iteração produto | NPS > 50 |

### 10.2 Roadmap de Captação

**Seed (atual):** R$ 500 mil
- Valuation pré: R$ 2 milhões
- Equity: 20%
- Investidores-alvo: Angels, micro-VCs, aceleradoras

**Série A (Ano 2):** R$ 3 milhões
- Valuation pré: R$ 12 milhões
- Equity: 20%
- Investidores-alvo: VCs early-stage (Canary, Astella, Bossa Nova)

**Série B (Ano 4):** R$ 15 milhões
- Valuation pré: R$ 60 milhões
- Equity: 20%
- Investidores-alvo: VCs growth (Kaszek, Monashees, Tiger Global)

### 10.3 Perguntas para Investidores

1. **Qual sua tese de investimento em healthtech/legaltech?**
2. **Experiência com modelos B2B SaaS de alto ticket?**
3. **Rede de relacionamento no setor hospitalar?**
4. **Expectativa de follow-on em rodadas futuras?**
5. **Apoio hands-on em quais áreas? (vendas, produto, contratação)**

---

## Apêndices

### A. Glossário

- **ANS:** Agência Nacional de Saúde Suplementar
- **CBHPM:** Classificação Brasileira Hierarquizada de Procedimentos Médicos
- **CNJ:** Conselho Nacional de Justiça
- **LGPD:** Lei Geral de Proteção de Dados
- **NLP:** Natural Language Processing (Processamento de Linguagem Natural)
- **SaaS:** Software as a Service
- **SUS:** Sistema Único de Saúde
- **TJ:** Tribunal de Justiça

### B. Referências

1. **CNJ - Relatório Justiça em Números 2024**  
   https://www.cnj.jus.br/pesquisas-judiciarias/justica-em-numeros/

2. **Folha/Piauí - Ações judiciais contra o SUS chegam a 345 mil em 2024**  
   https://piaui.folha.uol.com.br/acoes-judiciais-contra-o-sus-chegam-a-345-mil-em-2024/

3. **CNJ - Painel de Judicialização da Saúde**  
   https://www.cnj.jus.br/programas-e-acoes/forum-da-saude/

4. **IBGE - Estatísticas de Saúde 2024**  
   https://www.ibge.gov.br/estatisticas/sociais/saude.html

5. **ANAHP - Observatório da Saúde 2024**  
   https://www.anahp.com.br/

---

**Documento elaborado em:** Outubro de 2025  
**Versão:** 2.0 - JurisHealth  
**Confidencial:** Destinado exclusivamente a potenciais investidores

---

© 2025 JurisHealth. Todos os direitos reservados.

